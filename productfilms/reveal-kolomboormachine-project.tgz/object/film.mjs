export const FILM = {
  fig: "DHC",
  title: "Kolomboormachine",
  radius: 1150,
  label:
    "Een kolomboormachine van de Drachtster Hobby Club: hij draait in beeld, zoomt in op de boorkop, de bedieningsknoppen en de drie voedingshendels, de boor draait en zakt naar het werkstuk in de machineklem, en de machine valt uiteen in voet, kolom, tafel, kop, motor en snaarkap en klikt weer in elkaar.",
  bounds: [
    [-260, 260],
    [-400, 340],
    [0, 1730],
  ],
};

export const FIGURE = {
  title: "Kolomboormachine · anatomie",
  start: { yaw: -28, pitch: 16 },
  label:
    "Een staande kolomboormachine, opgebouwd uit {parts} losse onderdelen: een voetplaat met T-sleuven, een kolom met heugel, een ronde tafel met slinger en klem, een machineklem met werkstuk, de kop met pinole, spindel, boorkop en boor, drie voedingshendels, een noodstop, een motor met snaarschijven en een gele snaarkap. Uit elkaar zijn het {assemblies} delen.",
  keys: [
    { mark: "raised", label: "Voet, kolom en tafel" },
    { mark: "lit", label: "Spindel, boorkop en boor: draaien en zakken" },
    { mark: "edge", label: "Motor, snaar en kap: drijven de spindel aan" },
  ],
  caption:
    "{parts} bolle onderdelen, elk frame opnieuw geprojecteerd en gearceerd. Eerst gaan de snaarkap, de beschermkap en de hendels eraf, dan de snaar, het werkstuk, de boorkop en de boor; daarna komen de motor en de kop los, schuiven de klem en de tafel naar voren en komt de kolom uit zijn flens.",
};

export const FEATURE_DEFAULTS = { spin: 0, feed: 0 };

export const FEATURE_KEYS = [
  { key: "s", channel: "spin", name: "toeren", unit: "°", step: 360, ease: 0.2, verb: "laat de boor draaien" },
  { key: "f", channel: "feed", name: "voeding", unit: "", values: [0, 1], ease: 0.25, verb: "laat de boor zakken" },
];

const clamp01 = (x) => Math.max(0, Math.min(1, x));

export function featureValues(s, values) {
  return { ...values, spindle: s.spin, feed: 88 * clamp01(s.feed), "capstan.turn": -150 * clamp01(s.feed) };
}

export function featureTravel(a, b) {
  return Math.max((Math.abs(b.spin - a.spin) * Math.PI * 42) / 180, Math.abs(b.feed - a.feed) * 88);
}
