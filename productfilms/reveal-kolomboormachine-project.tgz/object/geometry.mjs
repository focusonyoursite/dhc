import * as G from "../kit/lathe.mjs";
const TAU = Math.PI * 2;
const unit = G.unit3;
const add = G.add3;
const mul = G.mul3;
const sub = G.sub3;
const dot = G.dot3;
const cross = G.cross3;
export const frame = (o, a, u) => {
  const A = unit(a);
  const U = unit(sub(u, mul(A, dot(u, A))));
  return { o, a: A, u: U, v: cross(A, U) };
};
const X = [1, 0, 0];
const Y = [0, 1, 0];
const Z = [0, 0, 1];
const NX = [-1, 0, 0];
const NY = [0, -1, 0];
const NZ = [0, 0, -1];

// Floor-standing pillar drill: 1730 mm tall, spindle 250 mm in front of the column, 88 mm quill stroke. Millimetres.
export const DRILL = { stroke: 88, sx: 0, sy: 140 };
const FONT = "'Big Shoulders Display','Arial Narrow',Arial,sans-serif";
const MONO = "'IBM Plex Mono',Menlo,monospace";

const ring = (r, steps = 72, cx = 0, cy = 0) =>
  Array.from({ length: steps }, (_, j) => {
    const a = (TAU * j) / steps;
    return `${j ? "L" : "M"}${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  }).join("") + "Z";
const rrect = (x0, y0, x1, y1, r) =>
  `M${x0 + r} ${y0}H${x1 - r}A${r} ${r} 0 0 1 ${x1} ${y0 + r}V${y1 - r}A${r} ${r} 0 0 1 ${x1 - r} ${y1}H${x0 + r}A${r} ${r} 0 0 1 ${x0} ${y1 - r}V${y0 + r}A${r} ${r} 0 0 1 ${x0 + r} ${y0}Z`;
const text = (x, y, s, size, { tone = "hi", anchor = "middle", weight = 700, family = FONT, style = "" } = {}) =>
  `<text class="iso-face-text" data-tone="${tone}" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}" style="font-family:${family};letter-spacing:.06em;${style}" transform="translate(${x.toFixed(2)} ${y.toFixed(2)})">${s}</text>`;
const line = (d, tone = "lo") => `<path class="iso-line" data-tone="${tone}" d="${d}"/>`;
function roundedRect(u0, v0, u1, v1, r, steps = 6) {
  const out = [];
  const corner = (cu, cv, a0) => {
    for (let j = 0; j <= steps; j++) {
      const a = a0 + (j / steps) * (Math.PI / 2);
      out.push([cu + r * Math.cos(a), cv + r * Math.sin(a)]);
    }
  };
  corner(u0 + r, v0 + r, Math.PI);
  corner(u1 - r, v0 + r, 1.5 * Math.PI);
  corner(u1 - r, v1 - r, 0);
  corner(u0 + r, v1 - r, 0.5 * Math.PI);
  return out;
}

export function buildObject(T, { layer }) {
  const parts = {};
  const groups = {};
  const explode = [];
  const anchors = {};
  const features = [];
  const L = layer;
  const root = T.group("root", { free: { origin: [0, 0, 860] } });
  groups.root = root;
  const assembly = (name, dir, travel, delay = 0, parent = root) => {
    const g = T.group(name, { parent, slide: { direction: unit(dir), travel } });
    groups[name] = g;
    explode.push({ name, travel, delay });
    return g;
  };
  const part = (p) => (parts[p.name] = p);
  const prism = (name, group, F, poly, s0, s1, o = {}) =>
    part(T.prism({ name, group, layer: L, F, polygon: poly, s0, s1, steps: 5, tone: o.tone ?? "hi", crease: o.crease ?? "lo", bevel: o.bevel ?? 0, material: o.material, lit: o.lit, details: o.details }));
  const round = (name, group, F, s0, s1, r, o = {}) =>
    part(T.round({ name, group, layer: L, F, s0, s1, r, ends: o.ends, tone: o.tone ?? "hi", crease: o.crease ?? "lo", material: o.material, lit: o.lit, details: o.details }));
  const plane = (p, o, u, v, svg, normal, fade = [0.04, 0.3]) => T.plane({ part: p, o, u, v, svg, normal, fade });
  const FZ = frame([0, 0, 0], Z, X);
  const box = (name, group, [x0, x1], [y0, y1], [z0, z1], o = {}) =>
    prism(name, group, FZ, o.r ? roundedRect(x0, y0, x1, y1, o.r) : [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], z0, z1, o);
  const FX = frame([0, 0, 0], X, Y);
  const side = (name, group, poly, x0, x1, o = {}) => prism(name, group, FX, poly, x0, x1, o);
  const up = (x, y) => frame([x, y, 0], Z, X);
  const FACE = {
    front: { u: [-1, 0, 0], v: NZ, n: Y },
    back: { u: X, v: NZ, n: NY },
    right: { u: Y, v: NZ, n: X },
    left: { u: NY, v: NZ, n: NX },
    top: { u: [-1, 0, 0], v: Y, n: Z },
  };
  const face = (p, f, o, svg, fade) => plane(p, o, FACE[f].u, FACE[f].v, svg, FACE[f].n, fade);
  const knurl = (s0, s1, count = 60) => ({ ribs: { s0, s1, count, fade: [0.08, 0.55], seams: true, tone: "lo" } });

  const SX = DRILL.sx;
  const SY = DRILL.sy;
  const COL = [0, -110];
  const AX = (y, z) => frame([0, y, z], X, Z);

  // ---------- Base and column ----------
  const base = box("base", root, [-240, 240], [-260, 330], [0, 60], { material: "gunmetal", r: 18, bevel: 3 });
  {
    let d = "";
    for (const x of [-80, 80]) d += `M${x - 12} -150V250M${x + 12} -150V250`;
    face(base, "top", [0, 35, 60.05], line(d, "lo") + line(rrect(-215, -280, 215, 280, 14), "faint"));
    face(base, "front", [0, 330.05, 30], text(0, 9, "DHC · B-32", 24, { family: MONO, weight: 600, tone: "mid" }));
  }
  for (const [i, [x, y]] of [[-205, -225], [205, -225], [-205, 295], [205, 295]].entries()) round(`base.bolt.${i}`, root, up(x, y), 60, 74, 12, { material: "chrome" });
  round("column.flange", root, up(...COL), 60, 100, 95, { material: "gunmetal", details: { seams: [88], bolts: [{ s: 100, r: 76, count: 4, size: 3, tone: "lo" }] } });
  const colG = assembly("column", Z, 340, 0.62);
  round("column", colG, up(...COL), 100, 1400, 46, { material: "chrome", details: { seams: [1250] } });
  const rackG = assembly("rack", X, 220, 0.5);
  const rack = box("rack", rackG, [46, 58], [-122, -98], [180, 1330], { material: "steel" });
  {
    let d = "";
    for (let z = -560; z <= 560; z += 10) d += `M-8 ${z}H8`;
    face(rack, "right", [58.05, -110, 755], line(d, "lo"), [0.06, 0.4]);
  }
  anchors.column = [0, -64, 1000];

  // ---------- Table ----------
  const tableG = assembly("table", Y, 400, 0.38);
  box("table.bracket", tableG, [-70, 70], [-62, -10], [690, 790], { material: "porcelain", r: 6 });
  for (const [n, x0, x1] of [["L", 52, 72], ["R", -72, -52]]) box(`table.cheek.${n}`, tableG, [x0, x1], [-96, -62], [690, 790], { material: "porcelain" });
  box("table.arm", tableG, [-45, 45], [-10, 90], [720, 790], { material: "porcelain", r: 4 });
  const table = round("table", tableG, up(SX, SY), 790, 830, 160, { material: "gunmetal", details: { seams: [818] } });
  plane(table, [SX, SY, 830.05], [-1, 0, 0], Y, line("M-112 -110H112M-112 110H112M-142 -60V60M142 -60V60", "lo") + line(ring(150, 90), "faint"), Z);
  round("table.crank.shaft", tableG, AX(-80, 740), 72, 110, 9, { material: "chrome" });
  box("table.crank.arm", tableG, [110, 120], [-94, -66], [730, 800], { material: "chrome", r: 3 });
  round("table.crank.grip", tableG, AX(-80, 790), 120, 160, 9, { material: "rubber" });
  round("table.lock.shaft", tableG, AX(-80, 740), -110, -72, 7, { material: "chrome" });
  round("table.lock.knob", tableG, AX(-80, 740), -134, -110, [10, 13], { material: "rubber" });
  anchors.table = [SX, SY, 830];

  // ---------- Vice and work ----------
  const viceG = assembly("vice", Y, 380, 0.3);
  box("vice.base", viceG, [-100, 100], [70, 210], [830, 850], { material: "gunmetal", r: 6 });
  const fj = box("vice.jaw.fixed", viceG, [-80, 80], [70, 95], [850, 900], { material: "porcelain", r: 3 });
  face(fj, "back", [0, 69.95, 875], line("M-70 -10H70M-70 10H70", "faint"));
  for (const [i, y0] of [100, 165].entries()) box(`vice.parallel.${i}`, viceG, [-70, 70], [y0, y0 + 15], [850, 860], { material: "steel" });
  const mjG = assembly("vice.jaw", Y, 160, 0.12, viceG);
  const mj = box("vice.jaw.moving", mjG, [-80, 80], [185, 210], [850, 900], { material: "porcelain", r: 3 });
  face(mj, "front", [0, 210.05, 875], line("M-70 -16H70", "faint"));
  round("vice.screw", mjG, frame([0, 210, 870], Y, Z), 0, 90, 8, { material: "chrome", details: { ribs: { s0: 4, s1: 86, count: 28, tone: "lo" } } });
  round("vice.boss", mjG, frame([0, 300, 870], Y, Z), 0, 16, 14, { material: "chrome" });
  round("vice.handle", mjG, frame([0, 322, 870], X, Z), -70, 70, 6, { material: "chrome" });
  for (const s of [-1, 1]) round(`vice.handle.end.${s > 0 ? "L" : "R"}`, mjG, frame([0, 322, 870], X, Z), s > 0 ? 70 : -82, s > 0 ? 82 : -70, 9, { material: "rubber" });
  const workG = assembly("work", X, 420, 0.06, viceG);
  const work = box("work", workG, [-60, 60], [95, 185], [860, 900], { material: "brass", bevel: 1 });
  face(work, "top", [0, 140, 900.05], line(ring(9, 36, 38, 0) + ring(9, 36, -38, 0), "mid") + line("M-50 -36H50", "faint"));
  anchors.work = [SX, SY, 905];

  // ---------- Head ----------
  const headG = assembly("head", Z, 520, 0.24);
  // The head is cut around the quill bore so the quill slides in a square well.
  const QB = [SY - 34, SY + 34];
  const headBack = box("head", headG, [-150, 150], [-190, QB[0]], [1400, 1630], { material: "porcelain", crease: "faint", bevel: 3 });
  const head = box("head.front", headG, [-150, 150], [QB[1], 215], [1400, 1630], { material: "porcelain", crease: "faint", bevel: 3 });
  box("head.cheek.L", headG, [34, 150], QB, [1400, 1630], { material: "porcelain", crease: "faint" });
  box("head.cheek.R", headG, [-150, -34], QB, [1400, 1630], { material: "porcelain", crease: "faint" });
  box("head.cap", headG, [-34, 34], QB, [1482, 1630], { material: "porcelain", crease: "faint" });
  {
    let svg = `<rect x="-130" y="-95" width="260" height="190" rx="12" style="fill:#e9e5dc;stroke:#8e8b85;stroke-width:2"/>`;
    svg += `<rect x="-130" y="-95" width="80" height="190" rx="10" style="fill:#d8d3c7"/>`;
    svg += text(45, -42, "DHC", 52, { style: "fill:#f2b705;letter-spacing:.02em" }) + text(45, -10, "B-32 · MK3", 18, { family: MONO, weight: 600, tone: "mid" });
    const sp = [250, 480, 820, 1250, 1750, 2500];
    for (let i = 0; i < 6; i++) svg += text(-5 + (i % 3) * 50, 30 + Math.floor(i / 3) * 26, String(sp[i]), 16, { family: MONO, weight: 600, tone: "mid" });
    svg += line("M-25 70H125", "faint") + text(-90, -10, "NOOD", 13, { family: MONO, weight: 600, tone: "mid" }) + text(-90, 78, "AAN", 13, { family: MONO, weight: 600, tone: "mid" });
    face(head, "front", [0, 215.05, 1520], svg);
    face(headBack, "right", [150.05, -40, 1520], `<rect x="-120" y="-40" width="240" height="80" rx="8" style="fill:#d8d3c7"/>` + text(0, -6, "DRACHTSTER HOBBY CLUB", 18, { family: MONO, weight: 600, tone: "mid" }) + text(0, 22, "230 V · 750 W · 2-8 KG", 14, { family: MONO, weight: 600, tone: "lo" }));
  }
  round("pulley.spindle", headG, up(SX, SY), 1630, 1690, 55, { material: "steel", details: { seams: [1645, 1660, 1675] } });
  round("depthstop", headG, up(-110, 190), 1336, 1400, 6, { material: "chrome", details: { ribs: { s0: 1340, s1: 1394, count: 18, tone: "lo" } } });
  round("depthstop.end", headG, up(-110, 190), 1290, 1320, 6, { material: "chrome" });
  round("depthstop.nut", headG, up(-110, 190), 1320, 1336, 13, { material: "brass" });
  const ctlG = assembly("controls", Y, 280, 0.02, headG);
  round("estop", ctlG, frame([90, 215, 1590], Y, Z), 0, 24, 28, { material: "signal", details: { seams: [9] } });
  round("switch.on", ctlG, frame([90, 215, 1500], Y, Z), 0, 14, 17, { material: "rubber" });
  anchors.controls = [40, 230, 1530];
  // Capstan feed handles on the operator's right (-x), turning with the quill.
  const capG = assembly("capstan", NX, 340, 0.04, headG);
  const capstan = T.group("capstan.turn", { parent: capG, hinge: { point: [-170, 60, 1500], axis: X, range: [-720, 720] } });
  groups.capstan = capstan;
  const CAPF = frame([0, 60, 1500], X, Z);
  round("capstan.boss", capstan, CAPF, -165, -150, 40, { material: "porcelain" });
  round("capstan.hub", capstan, CAPF, -200, -165, 30, { material: "chrome", details: { seams: [-182] } });
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * TAU - Math.PI / 6;
    const dir = [0, Math.cos(a), Math.sin(a)];
    const SF = frame([-183, 60, 1500], dir, X);
    round(`capstan.spoke.${k}`, capstan, SF, 30, 200, 8, { material: "chrome" });
    round(`capstan.knob.${k}`, capstan, SF, 200, 240, [11, 17], { material: "rubber" });
  }
  anchors.capstan = [-180, 60, 1500];
  // Quill, spindle, chuck and bit drop together on the feed.
  const feed = T.group("feed", { parent: headG, slide: { direction: NZ, travel: DRILL.stroke } });
  groups.feed = feed;
  const quillG = assembly("quill", NZ, 260, 0.3, feed);
  round("quill", quillG, up(SX, SY), 1250, 1480, 34, { material: "chrome", details: { ribs: { s0: 1270, s1: 1380, count: 22, tone: "lo" } } });
  const spin = T.group("spindle", { parent: quillG, hinge: { point: [SX, SY, 0], axis: Z, range: [-7200, 7200] } });
  groups.spindle = spin;
  const chuckG = assembly("chuck", Y, 420, 0.14, spin);
  round("spindle.nose", chuckG, up(SX, SY), 1225, 1250, 22, { material: "steel" });
  round("chuck.body", chuckG, up(SX, SY), 1165, 1225, 42, { material: "chrome", details: knurl(1172, 1218, 56) });
  round("chuck.nose", chuckG, up(SX, SY), 1132, 1165, [22, 36], { material: "steel", details: { seams: [1150] } });
  const bitG = assembly("bit", Y, 220, 0.2, chuckG);
  round("bit", bitG, up(SX, SY), 1002, 1132, 6, { material: "chrome", details: { ribs: { s0: 1006, s1: 1100, count: 26, tone: "lo" } } });
  round("bit.tip", bitG, up(SX, SY), 990, 1002, [0.6, 6], { material: "chrome" });
  anchors.chuck = [SX, SY, 1180];
  anchors.tool = [SX, SY, 950];
  // Chuck guard, swung open to the operator's right.
  const guardG = assembly("guard", NX, 420, 0.0, headG);
  box("guard.bracket", guardG, [-96, -80], [138, 176], [1290, 1400], { material: "gunmetal", r: 3 });
  const guard = box("guard", guardG, [-86, -80], [90, 230], [1120, 1290], { material: "dhc", r: 2.5 });
  face(guard, "left", [-86.05, 160, 1205], line("M-55 -70V70M55 -70V70", "faint"));

  // ---------- Motor, belt and cover ----------
  const motorG = assembly("motor", NY, 440, 0.2);
  round("motor", motorG, up(0, -300), 1440, 1630, 85, { material: "gunmetal", details: knurl(1450, 1600, 48) });
  round("motor.foot", motorG, up(0, -300), 1420, 1440, [60, 85], { material: "gunmetal" });
  box("motor.bracket", motorG, [-40, 40], [-215, -190], [1500, 1600], { material: "gunmetal", r: 4 });
  box("motor.box", motorG, [86, 110], [-330, -270], [1500, 1570], { material: "gunmetal", r: 4 });
  round("pulley.motor", motorG, up(0, -300), 1630, 1690, 55, { material: "steel", details: { seams: [1645, 1660, 1675] } });
  const beltG = assembly("belt", Z, 620, 0.08);
  for (const [n, s] of [["L", 1], ["R", -1]]) box(`belt.${n}`, beltG, s > 0 ? [57, 63] : [-63, -57], [-300, SY], [1660, 1672], { material: "rubber" });
  const coverG = assembly("cover", Z, 760, 0.0);
  const cover = box("cover", coverG, [-150, 150], [-395, 215], [1700, 1725], { material: "dhc", bevel: 3 });
  const skirt = box("cover.front", coverG, [-150, 150], [211, 215], [1630, 1700], { material: "dhc" });
  box("cover.back", coverG, [-150, 150], [-395, -391], [1630, 1700], { material: "dhc" });
  for (const [n, x0, x1] of [["L", 146, 150], ["R", -150, -146]]) box(`cover.side.${n}`, coverG, [x0, x1], [-391, 211], [1630, 1700], { material: "dhc" });
  face(skirt, "front", [0, 215.05, 1665], text(0, 6, "DRACHTSTER HOBBY CLUB", 14, { family: MONO, weight: 600, tone: "mid", style: "letter-spacing:.12em" }));
  face(cover, "top", [0, -90, 1725.05], line("M-110 -260H110M-110 260H110", "faint") + line("M-30 120A40 40 0 1 1 30 120", "mid"));
  anchors.cover = [0, -90, 1680];

  anchors.body = [0, 0, 860];
  for (let i = 0; i <= 8; i++) features.push({ spindle: i * 45, feed: (DRILL.stroke * i) / 8, "capstan.turn": -18.75 * i });
  return { parts, groups, explode, root, anchors, features, counts: {} };
}
export function explodeValues(explode, apart, { stretch = 0.55 } = {}) {
  const out = {};
  for (const { name, travel, delay } of explode) {
    const t = Math.max(0, Math.min(1, (apart - delay * stretch) / (1 - stretch)));
    out[name] = travel * t * t * (3 - 2 * t);
  }
  return out;
}
