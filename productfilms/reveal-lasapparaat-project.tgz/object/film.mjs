export const FILM = {
  fig: "DHC",
  title: "Lasapparaat",
  radius: 900,
  label:
    "Een MIG-lasapparaat van de Drachtster Hobby Club op een lastrolley: het draait in beeld, zoomt in op de lasbrander, de knoppen voor spanning en draadsnelheid, de draadspoel achter het zijluik en de gasfles met drukregelaar, en valt uiteen in trolley, apparaat, fles, brander en massaklem en klikt weer in elkaar.",
  bounds: [
    [-320, 320],
    [-340, 520],
    [0, 1160],
  ],
};

export const FIGURE = {
  title: "Lasapparaat · anatomie",
  start: { yaw: -30, pitch: 18 },
  label:
    "Een MIG-lasapparaat op een trolley, opgebouwd uit {parts} losse onderdelen: een trolley met grote achterwielen, zwenkwielen, plateaus en duwbeugel, een gasfles met spanband, kraan en drukregelaar met twee manometers, het gele lasapparaat met display, knoppen, Euro-aansluiting en massabus, een draadspoel achter een zijluik, de lasbrander met slang en houder, een massaklem met kabel en een lashelm. Uit elkaar zijn het {assemblies} delen.",
  keys: [
    { mark: "raised", label: "Trolley, wielen en gasfles" },
    { mark: "lit", label: "Lasapparaat, draadspoel en brander" },
    { mark: "edge", label: "Drukregelaar, massaklem en helm" },
  ],
  caption:
    "{parts} bolle onderdelen, elk frame opnieuw geprojecteerd en gearceerd. Eerst gaan de helm, de brander en de massaklem eraf, dan het zijluik, de knoppen, de drukregelaar en de draadspoel; daarna komen het apparaat, de spanband en de fles los en rollen de wielen opzij.",
};

export const FEATURE_DEFAULTS = { door: 0, spin: 0 };

export const FEATURE_KEYS = [
  { key: "d", channel: "door", name: "luik", unit: "", values: [0, 1], ease: 0.3, verb: "opent het zijluik" },
  { key: "s", channel: "spin", name: "spoel", unit: "°", step: 360, ease: 0.2, verb: "laat de draadspoel draaien" },
];

const clamp01 = (x) => Math.max(0, Math.min(1, x));

export function featureValues(s, values) {
  return { ...values, door: 105 * clamp01(s.door), spool: s.spin };
}

export function featureTravel(a, b) {
  return Math.max(Math.abs(b.door - a.door) * 340 * 1.8, (Math.abs(b.spin - a.spin) * Math.PI * 136) / 180);
}
