import * as G from "../kit/lathe.mjs";
const TAU = Math.PI * 2;
const unit = G.unit3;
const add = G.add3;
const mul = G.mul3;
const sub = G.sub3;
const dot = G.dot3;
const cross = G.cross3;
export const frame = (o, a, u) => {
  const A = unit(a);
  const U = unit(sub(u, mul(A, dot(u, A))));
  return { o, a: A, u: U, v: cross(A, U) };
};
const X = [1, 0, 0];
const Y = [0, 1, 0];
const Z = [0, 0, 1];
const NX = [-1, 0, 0];
const NY = [0, -1, 0];
const NZ = [0, 0, -1];

// MIG welding station on a trolley: welder, wire spool, gas bottle with regulator, torch and earth clamp. Millimetres.
export const WELD = { door: 105 };
const FONT = "'Big Shoulders Display','Arial Narrow',Arial,sans-serif";
const MONO = "'IBM Plex Mono',Menlo,monospace";

const ring = (r, steps = 72, cx = 0, cy = 0) =>
  Array.from({ length: steps }, (_, j) => {
    const a = (TAU * j) / steps;
    return `${j ? "L" : "M"}${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  }).join("") + "Z";
const rrect = (x0, y0, x1, y1, r) =>
  `M${x0 + r} ${y0}H${x1 - r}A${r} ${r} 0 0 1 ${x1} ${y0 + r}V${y1 - r}A${r} ${r} 0 0 1 ${x1 - r} ${y1}H${x0 + r}A${r} ${r} 0 0 1 ${x0} ${y1 - r}V${y0 + r}A${r} ${r} 0 0 1 ${x0 + r} ${y0}Z`;
const text = (x, y, s, size, { tone = "hi", anchor = "middle", weight = 700, family = FONT, style = "" } = {}) =>
  `<text class="iso-face-text" data-tone="${tone}" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}" style="font-family:${family};letter-spacing:.06em;${style}" transform="translate(${x.toFixed(2)} ${y.toFixed(2)})">${s}</text>`;
const line = (d, tone = "lo") => `<path class="iso-line" data-tone="${tone}" d="${d}"/>`;
function roundedRect(u0, v0, u1, v1, r, steps = 6) {
  const out = [];
  const corner = (cu, cv, a0) => {
    for (let j = 0; j <= steps; j++) {
      const a = a0 + (j / steps) * (Math.PI / 2);
      out.push([cu + r * Math.cos(a), cv + r * Math.sin(a)]);
    }
  };
  corner(u0 + r, v0 + r, Math.PI);
  corner(u1 - r, v0 + r, 1.5 * Math.PI);
  corner(u1 - r, v1 - r, 0);
  corner(u0 + r, v1 - r, 0.5 * Math.PI);
  return out;
}

export function buildObject(T, { layer }) {
  const parts = {};
  const groups = {};
  const explode = [];
  const anchors = {};
  const features = [];
  const L = layer;
  const root = T.group("root", { free: { origin: [0, 0, 600] } });
  groups.root = root;
  const assembly = (name, dir, travel, delay = 0, parent = root) => {
    const g = T.group(name, { parent, slide: { direction: unit(dir), travel } });
    groups[name] = g;
    explode.push({ name, travel, delay });
    return g;
  };
  const part = (p) => (parts[p.name] = p);
  const prism = (name, group, F, poly, s0, s1, o = {}) =>
    part(T.prism({ name, group, layer: L, F, polygon: poly, s0, s1, steps: 5, tone: o.tone ?? "hi", crease: o.crease ?? "lo", bevel: o.bevel ?? 0, material: o.material, lit: o.lit, details: o.details }));
  const round = (name, group, F, s0, s1, r, o = {}) =>
    part(T.round({ name, group, layer: L, F, s0, s1, r, ends: o.ends, tone: o.tone ?? "hi", crease: o.crease ?? "lo", material: o.material, lit: o.lit, details: o.details }));
  const plane = (p, o, u, v, svg, normal, fade = [0.04, 0.3]) => T.plane({ part: p, o, u, v, svg, normal, fade });
  const FZ = frame([0, 0, 0], Z, X);
  const box = (name, group, [x0, x1], [y0, y1], [z0, z1], o = {}) =>
    prism(name, group, FZ, o.r ? roundedRect(x0, y0, x1, y1, o.r) : [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], z0, z1, o);
  const FX = frame([0, 0, 0], X, Y);
  const side = (name, group, poly, x0, x1, o = {}) => prism(name, group, FX, poly, x0, x1, o);
  const up = (x, y) => frame([x, y, 0], Z, X);
  const FACE = {
    front: { u: [-1, 0, 0], v: NZ, n: Y },
    back: { u: X, v: NZ, n: NY },
    right: { u: Y, v: NZ, n: X },
    left: { u: NY, v: NZ, n: NX },
    top: { u: [-1, 0, 0], v: Y, n: Z },
  };
  const face = (p, f, o, svg, fade) => plane(p, o, FACE[f].u, FACE[f].v, svg, FACE[f].n, fade);
  const knurl = (s0, s1, count = 60) => ({ ribs: { s0, s1, count, fade: [0.08, 0.55], seams: true, tone: "lo" } });

  const AXX = (y, z) => frame([0, y, z], X, Z);
  const tube = (name, group, route, r, o = {}) =>
    T.tube({ name, group, layer: L, route: G.fillet(route, o.bend ?? 50, 9), r, chunk: o.chunk ?? 140, spacing: 6, turn: 24, material: o.material ?? "rubber", tone: "hi", gaps: o.gaps ?? [] });

  // ---------- Trolley ----------
  const base = box("cart.base", root, [-240, 240], [-330, 330], [110, 130], { material: "gunmetal", r: 8, bevel: 2 });
  face(base, "top", [0, 0, 130.05], line(rrect(-215, -305, 215, 305, 8), "faint"));
  for (const [n, x0, x1] of [["L", 220, 240], ["R", -240, -220]]) {
    box(`cart.upright.${n}`, root, [x0, x1], [-330, -310], [130, 1050], { material: "gunmetal" });
    box(`cart.rail.${n}`, root, [x0, x1], [-310, -60], [520, 540], { material: "gunmetal" });
    box(`cart.strap.rail.${n}`, root, n === "L" ? [200, 220] : [-220, -200], [-310, -58], [790, 810], { material: "steel" });
    round(`cart.post.${n}`, root, up(n === "L" ? 225 : -225, 315), 130, 520, 12, { material: "chrome" });
  }
  round("cart.handle", root, AXX(-320, 1064), -240, 240, 14, { material: "rubber", details: { ribs: { s0: -200, s1: 200, count: 40, tone: "faint" } } });
  const shelf = box("cart.shelf", root, [-240, 240], [-60, 330], [520, 540], { material: "gunmetal", r: 6 });
  face(shelf, "front", [0, 330.05, 530], line("M-220 0H220", "faint"));
  const strapG = assembly("strap", Z, 340, 0.2);
  box("cart.strap", strapG, [-200, 200], [-65, -58], [790, 810], { material: "steel" });
  // Wheels and casters.
  for (const [n, s] of [["L", 1], ["R", -1]]) {
    const wg = assembly(`wheel.${n}`, [s, 0, 0], 260, 0.62);
    round(`wheel.${n}.stub`, wg, AXX(-240, 120), s > 0 ? 240 : -250, s > 0 ? 250 : -240, 15, { material: "chrome" });
    round(`wheel.${n}`, wg, AXX(-240, 120), s > 0 ? 250 : -300, s > 0 ? 300 : -250, 120, { material: "rubber", details: { seams: [s > 0 ? 262 : -262, s > 0 ? 288 : -288] } });
    round(`wheel.${n}.hub`, wg, AXX(-240, 120), s > 0 ? 300 : -312, s > 0 ? 312 : -300, 46, { material: "chrome", details: { bolts: [{ s: s > 0 ? 312 : -312, r: 30, count: 5, size: 2.4, tone: "lo" }] } });
    const cg = assembly(`caster.${n}`, [s, 0, -0.2], 240, 0.6);
    const cx = s * 170;
    box(`caster.${n}.plate`, cg, [cx - 30, cx + 30], [220, 280], [100, 110], { material: "steel" });
    for (const [k, dx] of [-25, 25].entries()) box(`caster.${n}.cheek.${k}`, cg, [cx + dx - 5, cx + dx + 5], [235, 265], [40, 100], { material: "steel" });
    round(`caster.${n}.wheel`, cg, AXX(250, 50), cx - 18, cx + 18, 48, { material: "rubber", details: { seams: [cx] } });
  }

  // ---------- Gas bottle and regulator ----------
  const BY = -170;
  const btlG = assembly("bottle", Z, 640, 0.36);
  const bottle = round("bottle", btlG, up(0, BY), 130, 1000, 105, { material: "steel", details: { seams: [160, 960] } });
  plane(bottle, [0, BY + 105.05, 600], [-1, 0, 0], NZ, text(0, 0, "ARGON · CO₂", 24, { family: MONO, weight: 600, tone: "mid" }) + line("M-60 30H60", "faint"), Y);
  round("bottle.shoulder", btlG, up(0, BY), 1000, 1050, [105, 50], { material: "pcb" });
  round("bottle.neck", btlG, up(0, BY), 1050, 1066, 30, { material: "pcb" });
  round("bottle.valve", btlG, up(0, BY), 1066, 1100, 20, { material: "brass", details: knurl(1070, 1096, 30) });
  const regG = assembly("regulator", Z, 900, 0.12);
  box("regulator", regG, [-28, 28], [BY - 34, BY + 34], [1100, 1150], { material: "brass", r: 6 });
  for (const [k, y] of [BY - 24, BY + 24].entries()) {
    const g = round(`regulator.gauge.${k}`, regG, AXX(y, 1125), 28, 44, 22, { material: "chrome" });
    const a = -2.2 + k * 1.3;
    let ticks = "";
    for (let j = 0; j <= 8; j++) {
      const t = -2.4 + (j / 8) * 3.2;
      ticks += `M${(14 * Math.cos(t)).toFixed(1)} ${(14 * Math.sin(t)).toFixed(1)}L${(18 * Math.cos(t)).toFixed(1)} ${(18 * Math.sin(t)).toFixed(1)}`;
    }
    plane(g, [44.05, y, 1125], Y, NZ, `<circle r="19" style="fill:#f4f0e6"/>` + line(ticks, "mid") + line(`M0 0L${(15 * Math.cos(a)).toFixed(1)} ${(15 * Math.sin(a)).toFixed(1)}`, "hi"), X);
  }
  round("regulator.knob", regG, AXX(BY, 1125), -50, -28, 16, { material: "rubber", details: knurl(-48, -30, 30) });
  round("regulator.outlet", regG, frame([0, BY + 34, 1112], Y, Z), 0, 14, 8, { material: "brass" });
  anchors.gas = [20, BY, 1120];

  // ---------- Welder ----------
  const wG = assembly("welder", Z, 520, 0.3);
  const body = box("welder", wG, [-200, 60], [-40, 300], [540, 880], { material: "dhc", r: 10, bevel: 2 });
  {
    let svg = `<rect x="-60" y="-120" width="250" height="120" rx="8" style="fill:#2b2b2b"/>`;
    svg += text(65, -70, "MIG 200", 34, { style: "fill:#f2b705" }) + text(65, -36, "18.5 V · 6.0 M/MIN", 16, { family: MONO, weight: 600, style: "fill:#d8d3c7" });
    svg += text(150, 20, "SPANNING", 13, { family: MONO, weight: 600, tone: "lo" }) + text(60, 20, "DRAAD", 13, { family: MONO, weight: 600, tone: "lo" });
    svg += text(-160, -150, "DHC", 30, { style: "fill:#2b2b2b" }) + line("M-200 150H230", "lo");
    face(body, "front", [-70, 300.05, 760], svg);
    let vents = "";
    for (let k = 0; k < 9; k++) vents += `M-120 ${-80 + k * 20}H120`;
    face(body, "left", [-200.05, 130, 720], line(vents, "lo"));
  }
  for (const [n, z0, z1] of [["top", 860, 880], ["floor", 540, 560]]) box(`bay.${n}`, wG, [60, 200], [-40, 300], [z0, z1], { material: "dhc" });
  box("bay.back", wG, [60, 200], [-40, -20], [560, 860], { material: "dhc" });
  const bf = box("bay.front", wG, [60, 200], [280, 300], [560, 860], { material: "dhc" });
  face(bf, "front", [130, 300.05, 760], text(0, -40, "DRACHTSTER", 16, { family: MONO, weight: 600, tone: "lo" }) + text(0, -18, "HOBBY CLUB", 16, { family: MONO, weight: 600, tone: "lo" }));
  for (const [k, y] of [40, 240].entries()) box(`welder.post.${k}`, wG, [-80, -60], [y - 10, y + 10], [880, 908], { material: "gunmetal" });
  round("welder.handle", wG, frame([-70, 30, 920], Y, Z), 20, 220, 12, { material: "rubber" });
  // Front controls.
  const ctlG = assembly("controls", Y, 260, 0.24, wG);
  for (const [k, x] of [-150, -60].entries()) {
    round(`knob.${k}.skirt`, ctlG, frame([x, 300, 800], Y, Z), 0, 6, 30, { material: "gunmetal" });
    round(`knob.${k}`, ctlG, frame([x, 300, 800], Y, Z), 6, 34, 24, { material: "rubber", details: knurl(8, 32, 36) });
  }
  round("switch", ctlG, frame([20, 300, 800], Y, Z), 0, 18, 18, { material: "signal" });
  anchors.controls = [-80, 300, 770];
  // Sockets.
  const sockG = assembly("sockets", Y, 200, 0.22, wG);
  round("socket.euro", sockG, frame([-100, 300, 620], Y, Z), 0, 22, 26, { material: "brass", details: knurl(4, 20, 30) });
  round("socket.earth", sockG, frame([-30, 300, 620], Y, Z), 0, 16, 18, { material: "rubber" });
  // Wire spool behind the side door.
  const spool = T.group("spool", { parent: wG, hinge: { point: [0, 130, 710], axis: X, range: [-36000, 36000] } });
  groups.spool = spool;
  const spG = assembly("spool.reel", X, 420, 0.18, spool);
  round("spool.hub", spG, AXX(130, 710), 60, 80, 26, { material: "gunmetal" });
  const fl = round("spool.flange.in", spG, AXX(130, 710), 80, 86, 136, { material: "gunmetal" });
  void fl;
  round("spool.wire", spG, AXX(130, 710), 86, 174, 118, { material: "copper", details: { ribs: { s0: 88, s1: 172, count: 44, tone: "lo" } } });
  const flo = round("spool.flange.out", spG, AXX(130, 710), 174, 180, 136, { material: "steel" });
  plane(flo, [180.05, 130, 710], Y, NZ, line(ring(60, 48) + "M0 -110V-70M0 70V110M-110 0H-70M70 0H110", "lo") + text(0, 90, "0,8 MM", 16, { family: MONO, weight: 600, tone: "mid" }), X);
  anchors.spool = [150, 130, 710];
  const door = T.group("door", { parent: wG, hinge: { point: [200, 300, 0], axis: Z, range: [0, 180] } });
  groups.door = door;
  const dG = assembly("door.panel", [1, 0.3, 0], 700, 0.1, door);
  const dp = box("door.panel", dG, [200, 206], [-40, 300], [540, 880], { material: "dhc", bevel: 1 });
  {
    let vents = "";
    for (let k = 0; k < 6; k++) vents += `M-40 ${-140 + k * 16}H40`;
    face(dp, "right", [206.05, 130, 710], line(vents, "lo") + text(0, 80, "LASDRAAD", 18, { family: MONO, weight: 600, tone: "mid" }));
  }
  round("door.latch", dG, frame([206, 20, 710], X, Z), 0, 12, 12, { material: "rubber" });

  // ---------- Torch with its hose ----------
  const tG = assembly("torch", [-0.4, 0.6, 1], 760, 0.03);
  box("holster.top", tG, [-300, -200], [190, 202], [690, 700], { material: "steel" });
  box("holster.bot", tG, [-300, -200], [258, 270], [690, 700], { material: "steel" });
  round("torch.handle", tG, up(-270, 230), 560, 700, 20, { material: "rubber", details: { ribs: { s0: 570, s1: 690, count: 18, tone: "faint" } } });
  round("torch.collar", tG, up(-270, 230), 700, 712, 34, { material: "rubber" });
  box("torch.trigger", tG, [-276, -264], [250, 258], [640, 688], { material: "signal" });
  const NK = unit([0, 0.55, 0.835]);
  round("torch.neck", tG, frame([-270, 230, 719], NK, X), 0, 130, 11, { material: "chrome" });
  round("torch.nozzle", tG, frame([-270, 230, 719], NK, X), 130, 182, [15, 11], { material: "copper", details: { seams: [140] } });
  round("torch.tip", tG, frame([-270, 230, 719], NK, X), 182, 192, 4, { material: "copper" });
  round("torch.boot", tG, up(-270, 230), 532, 560, [13, 18], { material: "rubber" });
  tube("torch.hose", tG, [[-100, 322, 620], [-100, 430, 620], [-110, 470, 300], [-200, 430, 190], [-290, 320, 340], [-270, 230, 470], [-270, 230, 532]], 12);
  anchors.torch = [-260, 260, 700];

  // ---------- Earth clamp ----------
  const eG = assembly("earth", [0.3, 1, 0], 560, 0.08);
  box("earth.jaw.top", eG, [40, 80], [300, 362], [130, 142], { material: "chrome" });
  box("earth.jaw.bot", eG, [40, 80], [300, 362], [98, 110], { material: "chrome" });
  round("earth.pivot", eG, frame([0, 370, 120], X, Z), 40, 80, 9, { material: "steel" });
  box("earth.grip.top", eG, [42, 78], [379, 440], [131, 145], { material: "signal" });
  box("earth.grip.bot", eG, [42, 78], [379, 440], [95, 109], { material: "signal" });
  tube("earth.cable", eG, [[-30, 316, 620], [-30, 420, 620], [20, 480, 400], [60, 510, 200], [60, 480, 138], [60, 440, 138]], 9);

  // ---------- Helmet on top ----------
  const hG = assembly("helmet", Z, 800, 0.0);
  const helmet = prism("helmet", hG, FX, roundedRect(20, 880, 250, 1050, 60), 30, 190, { material: "rubber" });
  void helmet;
  const visor = box("helmet.visor", hG, [70, 150], [250, 256], [940, 990], { material: "glass" });
  face(visor, "front", [110, 256.05, 965], line("M-30 -12H30", "faint"));
  round("helmet.knob", hG, AXX(150, 965), 190, 204, 16, { material: "dhc" });

  anchors.body = [0, 0, 600];
  for (let i = 0; i <= 8; i++) features.push({ door: (WELD.door * i) / 8, spool: i * 45 });
  return { parts, groups, explode, root, anchors, features, counts: {} };
}
export function explodeValues(explode, apart, { stretch = 0.55 } = {}) {
  const out = {};
  for (const { name, travel, delay } of explode) {
    const t = Math.max(0, Math.min(1, (apart - delay * stretch) / (1 - stretch)));
    out[name] = travel * t * t * (3 - 2 * t);
  }
  return out;
}
