import { launch } from "./scripts/browser.mjs";
import { pathToFileURL } from "node:url";
const b = await launch(); const p = await b.newPage();
await p.goto(pathToFileURL(process.argv[2]).href); await p.waitForFunction(() => window.ready);
for (const spec of process.argv.slice(3)) {
  const r = await p.evaluate((s) => { globalThis.__t3unsep = []; window.set(JSON.parse(s)); return globalThis.__t3unsep.map(x => x.slice(0,2).join(" × ") + " " + (+x[2]).toFixed(2)); }, spec);
  console.log(spec, JSON.stringify(r));
}
await b.close();
