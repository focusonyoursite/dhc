import { launch } from "./scripts/browser.mjs";
import { pathToFileURL } from "node:url";
const b = await launch(); const p = await b.newPage();
await p.goto(pathToFileURL(process.argv[2]).href); await p.waitForFunction(() => window.ready);
for (const t of process.argv.slice(3).map(Number)) {
  const r = await p.evaluate((t) => { globalThis.__t3unsep = []; const s = window.frame(t); return [s.unseparated, globalThis.__t3unsep.map(x => x.slice(0,2).join(" × ") + " " + (+x[2]).toFixed(2))]; }, t);
  console.log(t, JSON.stringify(r));
}
await b.close();
