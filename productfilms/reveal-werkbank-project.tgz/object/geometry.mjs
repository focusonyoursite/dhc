import * as G from "../kit/lathe.mjs";
const TAU = Math.PI * 2;
const unit = G.unit3;
const add = G.add3;
const mul = G.mul3;
const sub = G.sub3;
const dot = G.dot3;
const cross = G.cross3;
export const frame = (o, a, u) => {
  const A = unit(a);
  const U = unit(sub(u, mul(A, dot(u, A))));
  return { o, a: A, u: U, v: cross(A, U) };
};
const X = [1, 0, 0];
const Y = [0, 1, 0];
const Z = [0, 0, 1];
const NX = [-1, 0, 0];
const NY = [0, -1, 0];
const NZ = [0, 0, -1];

// Beech woodworking bench: 1800 × 660 top at 900 mm, front vice, drawer and tool rack. Millimetres.
export const BENCH = { top: 900, vice: 120, drawer: 300, plane: 400 };
const FONT = "'Big Shoulders Display','Arial Narrow',Arial,sans-serif";
const MONO = "'IBM Plex Mono',Menlo,monospace";

const ring = (r, steps = 72, cx = 0, cy = 0) =>
  Array.from({ length: steps }, (_, j) => {
    const a = (TAU * j) / steps;
    return `${j ? "L" : "M"}${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  }).join("") + "Z";
const rrect = (x0, y0, x1, y1, r) =>
  `M${x0 + r} ${y0}H${x1 - r}A${r} ${r} 0 0 1 ${x1} ${y0 + r}V${y1 - r}A${r} ${r} 0 0 1 ${x1 - r} ${y1}H${x0 + r}A${r} ${r} 0 0 1 ${x0} ${y1 - r}V${y0 + r}A${r} ${r} 0 0 1 ${x0 + r} ${y0}Z`;
const text = (x, y, s, size, { tone = "hi", anchor = "middle", weight = 700, family = FONT, style = "" } = {}) =>
  `<text class="iso-face-text" data-tone="${tone}" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}" style="font-family:${family};letter-spacing:.06em;${style}" transform="translate(${x.toFixed(2)} ${y.toFixed(2)})">${s}</text>`;
const line = (d, tone = "lo") => `<path class="iso-line" data-tone="${tone}" d="${d}"/>`;
function roundedRect(u0, v0, u1, v1, r, steps = 6) {
  const out = [];
  const corner = (cu, cv, a0) => {
    for (let j = 0; j <= steps; j++) {
      const a = a0 + (j / steps) * (Math.PI / 2);
      out.push([cu + r * Math.cos(a), cv + r * Math.sin(a)]);
    }
  };
  corner(u0 + r, v0 + r, Math.PI);
  corner(u1 - r, v0 + r, 1.5 * Math.PI);
  corner(u1 - r, v1 - r, 0);
  corner(u0 + r, v1 - r, 0.5 * Math.PI);
  return out;
}

export function buildObject(T, { layer }) {
  const parts = {};
  const groups = {};
  const explode = [];
  const anchors = {};
  const features = [];
  const L = layer;
  const root = T.group("root", { free: { origin: [0, 0, 750] } });
  groups.root = root;
  const assembly = (name, dir, travel, delay = 0, parent = root) => {
    const g = T.group(name, { parent, slide: { direction: unit(dir), travel } });
    groups[name] = g;
    explode.push({ name, travel, delay });
    return g;
  };
  const part = (p) => (parts[p.name] = p);
  const prism = (name, group, F, poly, s0, s1, o = {}) =>
    part(T.prism({ name, group, layer: L, F, polygon: poly, s0, s1, steps: 5, tone: o.tone ?? "hi", crease: o.crease ?? "lo", bevel: o.bevel ?? 0, material: o.material, lit: o.lit, details: o.details }));
  const round = (name, group, F, s0, s1, r, o = {}) =>
    part(T.round({ name, group, layer: L, F, s0, s1, r, ends: o.ends, tone: o.tone ?? "hi", crease: o.crease ?? "lo", material: o.material, lit: o.lit, details: o.details }));
  const plane = (p, o, u, v, svg, normal, fade = [0.04, 0.3]) => T.plane({ part: p, o, u, v, svg, normal, fade });
  const FZ = frame([0, 0, 0], Z, X);
  const box = (name, group, [x0, x1], [y0, y1], [z0, z1], o = {}) =>
    prism(name, group, FZ, o.r ? roundedRect(x0, y0, x1, y1, o.r) : [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], z0, z1, o);
  const FX = frame([0, 0, 0], X, Y);
  const side = (name, group, poly, x0, x1, o = {}) => prism(name, group, FX, poly, x0, x1, o);
  const up = (x, y) => frame([x, y, 0], Z, X);
  const FACE = {
    front: { u: [-1, 0, 0], v: NZ, n: Y },
    back: { u: X, v: NZ, n: NY },
    right: { u: Y, v: NZ, n: X },
    left: { u: NY, v: NZ, n: NX },
    top: { u: [-1, 0, 0], v: Y, n: Z },
  };
  const face = (p, f, o, svg, fade) => plane(p, o, FACE[f].u, FACE[f].v, svg, FACE[f].n, fade);
  const knurl = (s0, s1, count = 60) => ({ ribs: { s0, s1, count, fade: [0.08, 0.55], seams: true, tone: "lo" } });

  const TOP = BENCH.top;
  const FY = frame([0, 0, 0], Y, Z); // extrude along y; polygon in (z, x)
  const sideY = (name, group, poly, y0, y1, o = {}) => prism(name, group, FY, poly, y0, y1, o);

  // ---------- Bench top and aprons ----------
  const topG = assembly("top", Z, 420, 0.5);
  const top = box("top", topG, [-900, 900], [-330, 330], [830, TOP], { material: "wood", crease: "lo", bevel: 3 });
  {
    let d = "";
    for (let y = -270; y <= 270; y += 60) d += `M-885 ${y}H885`;
    let holes = "";
    for (let x = -820; x <= 830; x += 150) holes += `M${-x - 10} -10h20v20h-20Z`;
    face(top, "top", [0, 0, TOP + 0.05], line(d, "faint") + line(holes, "mid"), [0.03, 0.2]);
    face(top, "front", [0, 330.05, 865], line("M-880 -20H880", "faint"));
  }
  for (const [n, x0, x1] of [["L", 310, 480], ["R", -900, -310]]) {
    const ap = box(`apron.${n}`, topG, [x0, x1], [300, 330], [760, 830], { material: "wood", crease: "lo" });
    if (n === "R") face(ap, "front", [(x0 + x1) / 2, 330.05, 795], text(0, 10, "DRACHTSTER HOBBY CLUB", 22, { family: MONO, weight: 600, tone: "lo", style: "letter-spacing:.22em" }));
  }
  box("apron.back", topG, [-900, 900], [-330, -300], [760, 830], { material: "wood", crease: "lo" });
  for (const [i, x] of [-520, 380].entries()) {
    const dg = assembly(`dog.${i}`, Z, 500, 0.1);
    box(`dog.${i}`, dg, [x - 12, x + 12], [-12, 12], [TOP, TOP + 28], { material: "brass", bevel: 1 });
  }
  anchors.top = [0, 0, TOP];

  // ---------- Base: legs, feet, stretchers, shelf ----------
  for (const [n, s] of [["L", 1], ["R", -1]]) {
    const lg = assembly(`legs.${n}`, [s, 0, 0], 360, 0.72);
    const x0 = s > 0 ? 720 : -800;
    const x1 = s > 0 ? 800 : -720;
    const foot = box(`foot.${n}`, lg, [x0, x1], [-330, 330], [0, 100], { material: "wood", crease: "lo", bevel: 2 });
    face(foot, "front", [(x0 + x1) / 2, 330.05, 50], line("M-30 -20H30", "faint"));
    for (const [k, y] of [-250, 250].entries()) box(`leg.${n}.${k}`, lg, [x0, x1], [y - 40, y + 40], [100, 830], { material: "wood", crease: "lo", bevel: 2 });
  }
  for (const [n, y0, y1, d] of [["f", 220, 280, Y], ["b", -280, -220, NY]]) {
    const sg = assembly(`stretcher.${n}`, d, 260, 0.66);
    box(`stretcher.${n}`, sg, [-720, 720], [y0, y1], [300, 380], { material: "wood", crease: "lo", bevel: 2 });
  }
  const shelfG = assembly("shelf", Z, 250, 0.6);
  const shelf = box("shelf", shelfG, [-720, 720], [-280, 280], [380, 400], { material: "wood", crease: "lo" });
  face(shelf, "top", [0, 0, 400.05], line("M-700 -140H700M-700 0H700M-700 140H700", "faint"), [0.05, 0.3]);

  // Toolbox on the shelf.
  const boxG = assembly("toolbox", Y, 560, 0.05);
  const tb = box("toolbox", boxG, [-600, -220], [-120, 120], [400, 560], { material: "dhc", r: 6, bevel: 2 });
  face(tb, "front", [-410, 120.05, 480], line("M-170 -50H170", "mid") + text(0, 20, "DHC", 40, { style: "fill:#2b2b2b" }));
  const lidG = assembly("toolbox.lid", Z, 60, 0.04, boxG);
  box("toolbox.lid", lidG, [-605, -215], [-125, 125], [560, 578], { material: "dhc", r: 6 });
  for (const [k, x] of [-500, -320].entries()) box(`toolbox.post.${k}`, lidG, [x - 6, x + 6], [-8, 8], [578, 630], { material: "gunmetal" });
  round("toolbox.handle", lidG, frame([0, 0, 615], X, Z), -494, -326, 9, { material: "rubber" });
  for (const [k, x] of [-570, -250].entries()) round(`toolbox.latch.${k}`, boxG, frame([x, 120, 540], Y, Z), 0, 6, 9, { material: "chrome" });

  // ---------- Drawer ----------
  for (const [n, x0, x1] of [["L", 300, 310], ["R", -310, -300]]) box(`runner.${n}`, topG, [x0, x1], [-280, 300], [700, 830], { material: "wood", crease: "lo" });
  const drawerSlide = T.group("drawer", { parent: root, slide: { direction: Y, travel: BENCH.drawer } });
  groups.drawer = drawerSlide;
  const drG = assembly("drawer.box", Y, 640, 0.14, drawerSlide);
  const dr = box("drawer.front", drG, [-300, 300], [300, 330], [705, 830], { material: "wood", crease: "lo", bevel: 2 });
  face(dr, "front", [0, 330.05, 767], line(rrect(-280, -52, 280, 52, 6), "faint") + text(-180, 12, "DHC", 30, { style: "fill:#f2b705" }));
  box("drawer.bottom", drG, [-290, 290], [-280, 300], [712, 724], { material: "wood", crease: "faint" });
  for (const [n, x0, x1] of [["L", 278, 290], ["R", -290, -278]]) box(`drawer.side.${n}`, drG, [x0, x1], [-268, 300], [724, 815], { material: "wood", crease: "faint" });
  box("drawer.back", drG, [-290, 290], [-280, -268], [724, 815], { material: "wood", crease: "faint" });
  // What lives in the drawer.
  const tape = round("drawer.tape", drG, up(-170, 150), 724, 766, 34, { material: "dhc", details: { seams: [745] } });
  plane(tape, [-170, 150, 766.05], [-1, 0, 0], Y, line(ring(20, 40), "mid") + line("M-8 0H8", "mid"), Z);
  box("drawer.tape.tab", drG, [-218, -204], [138, 162], [724, 736], { material: "steel" });
  round("drawer.pencil", drG, frame([0, 40, 731], X, Z), -110, 60, 6, { material: "signal" });
  round("drawer.pencil.tip", drG, frame([0, 40, 731], X, Z), 60, 78, [6, 1], { material: "wood" });
  const ruler = box("drawer.ruler", drG, [0, 230], [150, 180], [724, 738], { material: "dhc", bevel: 1 });
  {
    let d = "";
    for (let x = 0; x <= 220; x += 10) d += `M${-(x - 115)} -15V${x % 50 ? -8 : -2}`;
    face(ruler, "top", [115, 165, 738.05], line(d, "lo"));
  }
  const sb = box("drawer.screws", drG, [-120, -20], [-150, -40], [724, 770], { material: "porcelain", r: 6 });
  face(sb, "top", [-70, -95, 770.05], text(0, 6, "4×40", 18, { family: MONO, weight: 600, tone: "mid" }));
  box("drawer.box", drG, [80, 220], [-200, -60], [724, 760], { material: "porcelain", r: 6 });
  round("drawer.pull", drG, frame([0, 330, 767], Y, Z), 0, 14, [12, 16], { material: "brass" });
  anchors.drawer = [0, 420, 760];

  // ---------- Front vice ----------
  const vice = T.group("vice", { parent: root, slide: { direction: Y, travel: BENCH.vice } });
  groups.vice = vice;
  const vG = assembly("vice.chop", Y, 380, 0.05, vice);
  const chop = box("vice.chop", vG, [500, 800], [330, 380], [700, TOP], { material: "wood", crease: "lo", bevel: 3 });
  face(chop, "front", [650, 380.05, 800], line("M-130 -80H130", "faint"));
  for (const [k, x] of [540, 690].entries()) round(`vice.rod.${k}`, vG, frame([x, 150, 760], Y, Z), 0, 180, 12, { material: "chrome" });
  round("vice.screw", vG, frame([615, 150, 770], Y, Z), 0, 180, 15, { material: "steel", details: { ribs: { s0: 6, s1: 174, count: 34, tone: "lo" } } });
  round("vice.boss", vG, frame([615, 380, 770], Y, Z), 0, 34, 30, { material: "gunmetal", details: { seams: [10] } });
  const turn = T.group("vice.turn", { parent: vG, hinge: { point: [615, 0, 770], axis: Y, range: [-7200, 7200] } });
  groups["vice.turn"] = turn;
  round("vice.hub", turn, frame([615, 414, 770], Y, Z), 0, 16, 20, { material: "chrome" });
  round("vice.bar", turn, frame([615, 440, 770], X, Z), -150, 150, 9, { material: "chrome" });
  for (const s of [-1, 1]) round(`vice.bar.end.${s > 0 ? "L" : "R"}`, turn, frame([615, 440, 770], X, Z), s > 0 ? 150 : -170, s > 0 ? 170 : -150, 15, { material: "wood" });
  anchors.vice = [650, 380, 800];

  // ---------- Board and plane ----------
  const boardG = assembly("board", Z, 520, 0.12);
  const board = box("board", boardG, [-508, 300], [-70, 70], [TOP, TOP + 24], { material: "wood", crease: "lo", bevel: 1 });
  face(board, "top", [-104, 0, TOP + 24.05], line("M-390 -40C-200 -30 0 -50 390 -36M-390 10C-150 20 100 0 390 16M-390 44C-100 50 150 36 390 50", "faint"));
  const planeSlide = T.group("planeSlide", { parent: root, slide: { direction: X, travel: BENCH.plane } });
  groups.plane = planeSlide;
  const PZ = TOP + 24;
  const pG = assembly("plane", Z, 720, 0.0, planeSlide);
  const body = box("plane.body", pG, [-420, -180], [-28, 28], [PZ, PZ + 50], { material: "gunmetal", r: 6, bevel: 2 });
  face(body, "front", [-300, 28.05, PZ + 25], line("M-100 -10H100", "faint") + text(10, 8, "Nº 4", 16, { family: MONO, weight: 600, tone: "lo" }));
  const capG = assembly("plane.cap", Z, 120, 0.02, pG);
  sideY("plane.cap", capG, [[PZ + 50, -340], [PZ + 50, -250], [PZ + 70, -270], [PZ + 70, -340]], -22, 22, { material: "chrome", bevel: 1 });
  box("plane.iron", capG, [-350, -340], [-25, 25], [PZ + 50, PZ + 92], { material: "steel" });
  round("plane.adjuster", pG, up(-372, 0), PZ + 50, PZ + 64, 10, { material: "brass", details: knurl(PZ + 51, PZ + 63, 24) });
  sideY("plane.tote", pG, [[PZ + 50, -420], [PZ + 50, -386], [PZ + 128, -400], [PZ + 128, -430]], -11, 11, { material: "coffee", bevel: 2 });
  round("plane.knob", pG, up(-215, 0), PZ + 50, PZ + 96, [16, 22], { material: "coffee", details: { ends: undefined } });
  anchors.plane = [-90, 0, PZ + 40];

  // ---------- Tool rack ----------
  const rackG = assembly("rack", NY, 320, 0.2);
  const panel = box("rack.panel", rackG, [-860, 860], [-330, -312], [TOP, 1500], { material: "porcelain", crease: "faint" });
  {
    let d = "";
    for (let x = -820; x <= 820; x += 40) for (let z = 940; z <= 1400; z += 40) d += `M${x - 3} ${-(z - 1200)}a3 3 0 1 0 6 0a3 3 0 1 0 -6 0`;
    face(panel, "front", [0, -311.95, 1200], line(d, "faint") + text(0, -255, "DRACHTSTER HOBBY CLUB · GEREEDSCHAP", 26, { family: MONO, weight: 600, tone: "mid", style: "letter-spacing:.24em" }), [0.03, 0.25]);
  }
  for (const [k, x] of [-870, 860].entries()) box(`rack.post.${k}`, rackG, [x, x + 10], [-330, -300], [TOP, 1500], { material: "wood" });
  const tool = (name, delay) => assembly(name, [0, 1, 1.2], 520, delay, rackG);
  const peg = (name, g, x, z) => round(name, g, frame([x, -312, z], Y, Z), 0, 34, 4.5, { material: "chrome" });
  // Chisels.
  for (const [k, x] of [-720, -660, -600, -540].entries()) {
    const w = [6, 10, 14, 20][k];
    const g = tool(`chisel.${k}`, 0.02 + k * 0.015);
    peg(`chisel.${k}.peg`, g, x, 1330);
    round(`chisel.${k}.handle`, g, up(x, -296), 1210, 1320, [12, 15], { material: "coffee", details: { seams: [1300] } });
    round(`chisel.${k}.ferrule`, g, up(x, -296), 1194, 1210, 11, { material: "brass" });
    box(`chisel.${k}.blade`, g, [x - w / 2, x + w / 2], [-300, -293], [1060, 1194], { material: "steel" });
  }
  // Hammer on two pegs.
  {
    const g = tool("hammer", 0.06);
    for (const [k, x] of [-410, -350].entries()) peg(`hammer.peg.${k}`, g, x, 1325);
    box("hammer.head", g, [-445, -315], [-310, -282], [1330, 1362], { material: "steel", bevel: 2 });
    round("hammer.handle", g, up(-380, -296), 1110, 1330, 11, { material: "wood", details: { seams: [1140] } });
  }
  // Panel saw.
  {
    const g = tool("saw", 0.08);
    const blade = sideY("saw.blade", g, [[1110, -150], [1110, 260], [1230, 260], [1190, -150]], -301, -298, { material: "steel" });
    void blade;
    box("saw.handle", g, [260, 340], [-308, -291], [1120, 1240], { material: "wood", bevel: 2 });
    peg("saw.peg", g, 300, 1246);
  }
  // Try square.
  {
    const g = tool("square", 0.1);
    box("square.stock", g, [440, 462], [-308, -290], [1130, 1350], { material: "wood", bevel: 1 });
    box("square.blade", g, [462, 640], [-301, -297], [1328, 1350], { material: "steel" });
    peg("square.peg", g, 560, 1355);
  }
  // Mallet.
  {
    const g = tool("mallet", 0.12);
    box("mallet.head", g, [720, 820], [-312, -262], [1300, 1370], { material: "wood", crease: "lo", bevel: 3 });
    round("mallet.handle", g, up(770, -287), 1100, 1300, 12, { material: "coffee" });
  }
  anchors.rack = [-200, -300, 1250];

  anchors.body = [0, 0, 750];
  for (let i = 0; i <= 8; i++) features.push({ vice: (BENCH.vice * i) / 8, "vice.turn": i * 90, drawer: (BENCH.drawer * i) / 8, planeSlide: (BENCH.plane * i) / 8 });
  return { parts, groups, explode, root, anchors, features, counts: {} };
}
export function explodeValues(explode, apart, { stretch = 0.55 } = {}) {
  const out = {};
  for (const { name, travel, delay } of explode) {
    const t = Math.max(0, Math.min(1, (apart - delay * stretch) / (1 - stretch)));
    out[name] = travel * t * t * (3 - 2 * t);
  }
  return out;
}
