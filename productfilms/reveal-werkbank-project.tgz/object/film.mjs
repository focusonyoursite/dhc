export const FILM = {
  fig: "DHC",
  title: "Werkbank",
  radius: 1300,
  label:
    "Een beuken werkbank van de Drachtster Hobby Club: hij draait in beeld, zoomt in op de voortang die opendraait, het gereedschapsbord, de lade die naar buiten schuift en een schaaf die over een plank loopt, en de bank valt uiteen in blad, onderstel, lade, tang en gereedschap en klikt weer in elkaar.",
  bounds: [
    [-900, 900],
    [-340, 440],
    [0, 1500],
  ],
};

export const FIGURE = {
  title: "Werkbank · anatomie",
  start: { yaw: -24, pitch: 18 },
  label:
    "Een beuken werkbank van 1800 mm, opgebouwd uit {parts} losse onderdelen: een gelamineerd blad met bankhaakgaten en twee bankhaken, een onderstel met voeten, poten, regels en een plank, een gele gereedschapskist, een lade op geleiders, een voortang met spindel, geleidestangen en draaiboom, een plank met een blokschaaf en een gereedschapsbord met beitels, hamer, zaag, winkelhaak en houten hamer. Uit elkaar zijn het {assemblies} delen.",
  keys: [
    { mark: "raised", label: "Blad, poten en onderstel" },
    { mark: "lit", label: "Voortang, lade en schaaf: bewegen" },
    { mark: "edge", label: "Gereedschapsbord en kist" },
  ],
  caption:
    "{parts} bolle onderdelen, elk frame opnieuw geprojecteerd en gearceerd. Eerst gaan de schaaf, het gereedschap en de tang eraf, dan de plank, de bankhaken, de lade en de kist; daarna het bord en het blad, en ten slotte vallen de regels en de poten opzij.",
};

export const FEATURE_DEFAULTS = { vice: 0, drawer: 0, plane: 0 };

export const FEATURE_KEYS = [
  { key: "v", channel: "vice", name: "tang", unit: "", values: [0, 1], ease: 0.3, verb: "draait de voortang open" },
  { key: "l", channel: "drawer", name: "lade", unit: "", values: [0, 1], ease: 0.3, verb: "trekt de lade open" },
  { key: "p", channel: "plane", name: "schaaf", unit: "", values: [0, 1], ease: 0.3, verb: "laat de schaaf over de plank lopen" },
];

const clamp01 = (x) => Math.max(0, Math.min(1, x));

export function featureValues(s, values) {
  const v = clamp01(s.vice);
  return { ...values, vice: 120 * v, "vice.turn": 1440 * v, drawer: 300 * clamp01(s.drawer), planeSlide: 400 * clamp01(s.plane) };
}

export function featureTravel(a, b) {
  return Math.max(Math.abs(b.vice - a.vice) * 120, Math.abs(b.drawer - a.drawer) * 300, Math.abs(b.plane - a.plane) * 400);
}
