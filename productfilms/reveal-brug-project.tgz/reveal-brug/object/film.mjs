export const FILM = {
  fig: "DHC",
  title: "Autobrug",
  radius: 3150,
  label:
    "Een tweekoloms autobrug van de Drachtster Hobby Club met een gele hatchback op de armen: de brug draait in beeld, zoomt in op de bedieningskast, de hydraulische pomp en een draagschotel, tilt de auto omhoog, valt uiteen in kolommen, sleden, armen en auto en klikt weer in elkaar.",
  bounds: [
    [-2050, 2050],
    [-2050, 2050],
    [0, 3010],
  ],
};

export const FIGURE = {
  title: "Autobrug · anatomie",
  start: { yaw: -30, pitch: 16 },
  label:
    "Een tweekoloms autobrug van 4 ton, opgebouwd uit {parts} losse onderdelen: twee kolommen met voetplaat, flenzen en een vanggrendelladder, sleden met vier telescoopzwenkarmen en rubberen draagschotels, een bovenligger met uitschakelbeugel, een hydraulische pomp met motor en olietank, een bedieningskast en een gele hatchback. Uit elkaar zijn het {assemblies} delen.",
  keys: [
    { mark: "raised", label: "Kolommen, voetplaten en bovenligger" },
    { mark: "lit", label: "Sleden, armen en draagschotels: dragen de auto" },
    { mark: "edge", label: "Hydrauliek: pomp, motor, tank, bediening" },
  ],
  caption:
    "{parts} bolle onderdelen, elk frame opnieuw geprojecteerd en gearceerd. De auto gaat er als eerste af, dan de bovenligger, de flenzen van de kolommen en de pomp; daarna schuiven de sleden met hun armen naar binnen en zakken de voetplaten weg.",
};

export const FEATURE_DEFAULTS = { lift: 0 };

export const FEATURE_KEYS = [{ key: "l", channel: "lift", name: "lift", unit: "", values: [0, 1], ease: 0.25, verb: "tilt de auto omhoog" }];

const clamp01 = (x) => Math.max(0, Math.min(1, x));

export function featureValues(s, values) {
  return { ...values, lift: 1200 * clamp01(s.lift) };
}

export function featureTravel(a, b) {
  return Math.abs(b.lift - a.lift) * 1200;
}
