import * as G from "../kit/lathe.mjs";
const TAU = Math.PI * 2;
const unit = G.unit3;
const add = G.add3;
const mul = G.mul3;
const sub = G.sub3;
const dot = G.dot3;
const cross = G.cross3;
export const frame = (o, a, u) => {
  const A = unit(a);
  const U = unit(sub(u, mul(A, dot(u, A))));
  return { o, a: A, u: U, v: cross(A, U) };
};
const X = [1, 0, 0];
const Y = [0, 1, 0];
const Z = [0, 0, 1];
const NX = [-1, 0, 0];
const NY = [0, -1, 0];
const NZ = [0, 0, -1];

// Two-post clear-floor lift, 4.0 t, with a small hatchback on its arms. Millimetres.
export const LIFT = { post: 1650, half: 150, web: 15, top: 2850, open: 100, base: 20, travel: 1200 };
export const CAR = { half: 880, len: 2000, sill: 200, belt: 650, deck: 1000, wheelY: 1250, wheelR: 310, track: 650, tyreW: 200 };
const FONT = "'Big Shoulders Display','Arial Narrow',Arial,sans-serif";
const MONO = "'IBM Plex Mono',Menlo,monospace";

const ring = (r, steps = 72, cx = 0, cy = 0) =>
  Array.from({ length: steps }, (_, j) => {
    const a = (TAU * j) / steps;
    return `${j ? "L" : "M"}${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  }).join("") + "Z";
const rrect = (x0, y0, x1, y1, r) =>
  `M${x0 + r} ${y0}H${x1 - r}A${r} ${r} 0 0 1 ${x1} ${y0 + r}V${y1 - r}A${r} ${r} 0 0 1 ${x1 - r} ${y1}H${x0 + r}A${r} ${r} 0 0 1 ${x0} ${y1 - r}V${y0 + r}A${r} ${r} 0 0 1 ${x0 + r} ${y0}Z`;
const text = (x, y, s, size, { tone = "hi", anchor = "middle", weight = 700, family = FONT, style = "" } = {}) =>
  `<text class="iso-face-text" data-tone="${tone}" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}" style="font-family:${family};letter-spacing:.06em;${style}" transform="translate(${x.toFixed(2)} ${y.toFixed(2)})">${s}</text>`;
const line = (d, tone = "lo") => `<path class="iso-line" data-tone="${tone}" d="${d}"/>`;
function roundedRect(u0, v0, u1, v1, r, steps = 6) {
  const out = [];
  const corner = (cu, cv, a0) => {
    for (let j = 0; j <= steps; j++) {
      const a = a0 + (j / steps) * (Math.PI / 2);
      out.push([cu + r * Math.cos(a), cv + r * Math.sin(a)]);
    }
  };
  corner(u0 + r, v0 + r, Math.PI);
  corner(u1 - r, v0 + r, 1.5 * Math.PI);
  corner(u1 - r, v1 - r, 0);
  corner(u0 + r, v1 - r, 0.5 * Math.PI);
  return out;
}

export function buildObject(T, { layer }) {
  const parts = {};
  const groups = {};
  const explode = [];
  const anchors = {};
  const features = [];
  const L = layer;
  const root = T.group("root", { free: { origin: [0, 0, 1400] } });
  groups.root = root;
  const assembly = (name, dir, travel, delay = 0, parent = root) => {
    const g = T.group(name, { parent, slide: { direction: unit(dir), travel } });
    groups[name] = g;
    explode.push({ name, travel, delay });
    return g;
  };
  const part = (p) => (parts[p.name] = p);
  const prism = (name, group, F, poly, s0, s1, o = {}) =>
    part(T.prism({ name, group, layer: L, F, polygon: poly, s0, s1, steps: 5, tone: o.tone ?? "hi", crease: o.crease ?? "lo", bevel: o.bevel ?? 0, material: o.material, lit: o.lit, details: o.details }));
  const round = (name, group, F, s0, s1, r, o = {}) =>
    part(T.round({ name, group, layer: L, F, s0, s1, r, ends: o.ends, tone: o.tone ?? "hi", crease: o.crease ?? "lo", material: o.material, lit: o.lit, details: o.details }));
  const plane = (p, o, u, v, svg, normal, fade = [0.04, 0.3]) => T.plane({ part: p, o, u, v, svg, normal, fade });
  // A box in world axes; polygon u = x, v = y.
  const FZ = frame([0, 0, 0], Z, X);
  const box = (name, group, [x0, x1], [y0, y1], [z0, z1], o = {}) =>
    prism(name, group, FZ, o.r ? roundedRect(x0, y0, x1, y1, o.r) : [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], z0, z1, o);
  // A side profile in (y, z), extruded along x.
  const FX = frame([0, 0, 0], X, Y);
  const side = (name, group, poly, x0, x1, o = {}) => prism(name, group, FX, poly, x0, x1, o);
  const up = (x, y) => frame([x, y, 0], Z, X);
  // Face plane directions, seen from outside: u = drawing right, v = drawing down.
  const FACE = {
    front: { u: [-1, 0, 0], v: NZ, n: Y },
    back: { u: X, v: NZ, n: NY },
    right: { u: Y, v: NZ, n: X },
    left: { u: NY, v: NZ, n: NX },
    top: { u: [-1, 0, 0], v: Y, n: Z },
  };
  const face = (p, f, o, svg, fade) => plane(p, o, FACE[f].u, FACE[f].v, svg, FACE[f].n, fade);

  const { post: PX, half: H, web: WEB, top: TOP, open: OPEN, base: BASE, travel } = LIFT;
  const lift = T.group("lift", { parent: root, slide: { direction: Z, travel } });
  groups.lift = lift;

  // ---------- Posts ----------
  for (const s of [-1, 1]) {
    const S = s < 0 ? "L" : "R";
    const out = (a) => s * a; // world x of a distance from the centre line
    const span = (a, b) => [Math.min(out(a), out(b)), Math.max(out(a), out(b))];
    const xo = PX + H; // outer face of the web
    const xi = PX - H; // inner (open) side
    const baseG = assembly(`base.${S}`, NZ, 160, 0.42);
    const plate = box(`base.${S}`, baseG, span(xi - 210, xo + 60), [-330, 330], [0, BASE], { material: "gunmetal", r: 20 });
    {
      let d = "";
      for (let k = -300; k <= 300; k += 30) d += `M${k} -310L${k + 20} -290`;
      face(plate, "top", [s * (PX - 75), 0, BASE + 0.05], line(d, "faint"), [0.08, 0.5]);
    }
    for (const [bx, by] of [[xi - 160, -270], [xi - 160, 270], [xo + 15, -270], [xo + 15, 270]]) {
      const g = assembly(`anchor.${S}.${by > 0 ? "f" : "b"}${bx > PX ? "o" : "i"}`, Z, 260, 0.3, baseG);
      round(`anchor.${S}.${by > 0 ? "f" : "b"}${bx > PX ? "o" : "i"}`, g, up(out(bx), by), BASE, BASE + 22, 22, { material: "chrome", details: { seams: [BASE + 8] } });
    }
    const webG = assembly(`web.${S}`, [s, 0, 0], 520, 0.3);
    const web = box(`post.${S}.web`, webG, span(xo - WEB, xo), [-H, H], [BASE, TOP], { material: "steel", crease: "faint" });
    {
      // Safety-lock ladder on the inside of the web.
      let d = "";
      for (let z = 300; z <= 2500; z += 90) d += `M-40 ${-z}h80M-40 ${-z - 30}h80`;
      face(web, s < 0 ? "right" : "left", [out(xo - WEB) + s * -0.05, 0, 0], line(`M-60 -200V-2600M60 -200V-2600`, "mid") + line(d, "lo"), [0.03, 0.25]);
      let e = "";
      for (let z = 400; z <= 2600; z += 220) e += `M-120 ${-z}h240`;
      face(web, s < 0 ? "left" : "right", [out(xo) + s * 0.05, 0, 0], line(e, "faint"), [0.05, 0.4]);
    }
    for (const f of [-1, 1]) {
      const F = f > 0 ? "f" : "b";
      const flG = assembly(`flange.${S}.${F}`, [0, f, 0], 330, 0.16);
      const fl = box(`post.${S}.flange.${F}`, flG, span(xi, xo - WEB), f > 0 ? [H - WEB, H] : [-H, -H + WEB], [BASE, TOP], { material: "steel", crease: "faint" });
      box(`post.${S}.lip.${F}`, flG, span(xi, xi + WEB), f > 0 ? [OPEN, H - WEB] : [-H + WEB, -OPEN], [BASE, TOP], { material: "steel", crease: "faint" });
      if (f > 0) {
        let d = "";
        for (let z = 200; z <= 2700; z += 300) d += `M-120 ${-z}h240`;
        const o = [s * PX, H + 0.05, 0];
        let svg = line(d, "faint");
        if (s > 0) svg += `<rect x="-95" y="-1760" width="190" height="120" rx="8" style="fill:#f2c230"/>` + text(0, -1690, "4.0 T", 64, { style: "fill:#1a1a1a" }) + text(0, -1650, "MAX 2000 KG/ARM", 18, { family: MONO, weight: 600, style: "fill:#1a1a1a" });
        face(fl, "front", o, svg, [0.04, 0.3]);
      }
    }
    const capG = assembly(`cap.${S}`, Z, 420, 0.1);
    box(`post.${S}.cap`, capG, span(xi - 10, xo + 10), [-H - 10, H + 10], [TOP, TOP + 20], { material: "gunmetal", r: 8 });
    for (const f of [-1, 1]) {
      const pg = assembly(`pulley.${S}.${f > 0 ? "f" : "b"}`, [0, f, 1], 380, 0.02, capG);
      round(`pulley.${S}.${f > 0 ? "f" : "b"}`, pg, frame([0, f * 135, TOP + 20 + 60], X, Z), Math.min(s * (xo - 80), s * (xo - 30)), Math.max(s * (xo - 80), s * (xo - 30)), 58, { material: "chrome", details: { seams: [] , ribs: undefined } });
    }

    // Rubber door guard on the inner front edge.
    const guardG = assembly(`guard.${S}`, [0, 1, 0], 420, 0.04);
    const gz = s < 0 ? [450, 1250] : [700, 1500];
    const guard = box(`guard.${S}`, guardG, span(xi + 20, xi + 120), [H, H + 40], gz, { material: "rubber", r: 10 });
    {
      let d = "";
      const zc = (gz[0] + gz[1]) / 2;
      for (let z = gz[0] + 60; z <= gz[1] - 60; z += 40) d += `M-40 ${-(z - zc)}h80`;
      face(guard, "front", [s * (xi + 70), H + 40.05, zc], line(d, "lo"));
    }

    // Carriage: a slide inside the post, a neck through the opening, two pivot bosses.
    const carG = assembly(`carriage.${S}`, [-s, 0, 0.35], 350, 0.34, lift);
    const z0 = 100;
    const z1 = 1100;
    const slide = box(`carriage.${S}.slide`, carG, span(xo - WEB - 10 - 225, xo - WEB - 10), [-125, 125], [z0, z1], { material: "gunmetal" });
    const neck = box(`carriage.${S}.neck`, carG, span(xi - 50, xi + 25), [-90, 90], [z0, z1], { material: "gunmetal", crease: "lo" });
    {
      let d = "";
      for (let z = 180; z <= 1020; z += 60) d += `M-70 ${-(z - 600)}h140`;
      face(neck, s < 0 ? "right" : "left", [out(xi - 50) + s * 0.05, 0, 600], line(d, "faint") + `<circle cx="0" cy="-380" r="22" style="fill:#2b2b2b"/>`);
    }
    // Lock pawl on top of the slide.
    round(`carriage.${S}.pawl`, carG, frame([out(xo - WEB - 120), 0, z1], Z, X), 0, 40, 30, { material: "signal" });
    anchors[`carriage.${S}`] = [out(xi - 50), 0, 700];

    // ---------- Arms ----------
    for (const f of [-1, 1]) {
      const F = f > 0 ? "f" : "b";
      const pv = [out(xi - 90), f * 70, 0];
      const padAt = [out(CAR.track), f * 800, 0];
      const dir = unit([padAt[0] - pv[0], padAt[1] - pv[1], 0]);
      const len = Math.hypot(padAt[0] - pv[0], padAt[1] - pv[1]);
      const armG = assembly(`arm.${S}.${F}`, [-s * 0.2, f, 0.55], 700, 0.24, carG);
      round(`arm.${S}.${F}.boss`, armG, up(pv[0], pv[1]), z0, z0 + 10, 40, { material: "gunmetal" });
      const AF = frame(pv, dir, Z);
      const outer = prism(`arm.${S}.${F}.outer`, armG, AF, roundedRect(z0 + 10, -46, z0 + 80, 46, 6), 0, len * 0.62, { material: "gunmetal" });
      {
        const vdir = cross(dir, Z);
        plane(outer, add([pv[0], pv[1], z0 + 80.05], mul(dir, len * 0.31)), mul(dir, 1), mul(vdir, -1), line(`M${-len * 0.27} -20H${len * 0.27}M${-len * 0.27} 20H${len * 0.27}`, "faint") + `<circle cx="${-len * 0.29}" cy="0" r="14" style="fill:#2b2b2b"/>`, Z);
      }
      const innerG = T.group(`arm.${S}.${F}.ext`, { parent: armG, slide: { direction: dir, travel: 260 } });
      groups[`arm.${S}.${F}.ext`] = innerG;
      prism(`arm.${S}.${F}.inner`, innerG, AF, roundedRect(z0 + 18, -36, z0 + 72, 36, 5), len * 0.62, len + 70, { material: "chrome", details: { seams: [len * 0.62 + 30] } });
      const padG = assembly(`pad.${S}.${F}`, Z, 420, 0.12, innerG);
      const PF = up(padAt[0], padAt[1]);
      round(`pad.${S}.${F}.screw`, padG, PF, z0 + 72, z0 + 82, 42, { material: "chrome", details: { ribs: { s0: z0 + 73, s1: z0 + 81, count: 40, tone: "lo" } } });
      const pad = round(`pad.${S}.${F}.rubber`, padG, PF, z0 + 82, CAR.sill, 62, { material: "rubber" });
      {
        let d = "";
        for (let k = -40; k <= 40; k += 16) d += `M${k} -44V44`;
        plane(pad, [padAt[0], padAt[1], CAR.sill + 0.05], [-1, 0, 0], Y, `<circle r="58" style="fill:#3a3a3c"/>` + line(d, "lo"), Z, [0.04, 0.3]);
      }
      round(`arm.${S}.${F}.pin`, armG, up(pv[0], pv[1]), z0 + 80, z0 + 96, 24, { material: "chrome" });
      anchors[`pad.${S}.${F}`] = [padAt[0], padAt[1], CAR.sill];
    }
  }

  // ---------- Overhead beam and shut-off bar ----------
  const beamG = assembly("beam", Z, 560, 0.04);
  const beam = box("beam", beamG, [-PX - 120, PX + 120], [-70, 70], [TOP + 20, TOP + 160], { material: "steel", crease: "faint" });
  {
    let d = "";
    for (let x = -1500; x <= 1500; x += 250) d += `M${x} -50V50`;
    face(beam, "front", [0, 70.05, TOP + 90], line(`M-1700 -40H1700M-1700 40H1700`, "faint") + text(0, 22, "DRACHTSTER HOBBY CLUB", 64, { tone: "hi", style: "letter-spacing:.32em" }));
    face(beam, "top", [0, 0, TOP + 160.05], line(d, "faint"));
  }
  const barG = assembly("bar", NZ, 180, 0.06, beamG);
  for (const sx of [-1, 1]) round(`bar.hanger.${sx > 0 ? "R" : "L"}`, barG, up(sx * 1200, 0), TOP - 100, TOP + 20, 10, { material: "chrome" });
  box("bar", barG, [-1300, 1300], [-28, 28], [TOP - 150, TOP - 100], { material: "rubber", r: 14 });

  // ---------- Power unit on the left post ----------
  const puG = assembly("power", NX, 620, 0.1);
  {
    const xo = -(PX + H);
    box("power.bracket", puG, [xo - 20, xo], [-130, 130], [1050, 1560], { material: "gunmetal" });
    const tank = box("power.tank", puG, [xo - 200, xo - 20], [-110, 110], [1060, 1330], { material: "glass", r: 18 });
    face(tank, "left", [xo - 200.05, 0, 1195], line("M-80 -60h40M-80 -10h40M-80 40h40", "mid") + text(-30, -55, "MAX", 22, { tone: "mid", anchor: "start", family: MONO }) + text(-30, 45, "MIN", 22, { tone: "mid", anchor: "start", family: MONO }) + line("M-100 10H100", "lo"));
    const pump = box("power.pump", puG, [xo - 190, xo - 20], [-100, 100], [1330, 1420], { material: "chrome" });
    face(pump, "left", [xo - 190.05, 0, 1375], `<circle cx="-50" cy="0" r="14" style="fill:#2b2b2b"/><circle cx="50" cy="0" r="14" style="fill:#2b2b2b"/>`);
    const motor = round("power.motor", puG, up(xo - 105, 0), 1420, 1720, 85, { material: "signal", details: { ribs: { s0: 1440, s1: 1690, count: 36, fade: [0.08, 0.55], seams: true, tone: "lo" } } });
    round("power.fan", puG, up(xo - 105, 0), 1720, 1760, [85, 70], { material: "gunmetal", details: { seams: [1735] } });
    // Lowering lever.
    const lv = assembly("power.lever", [-1, 0.6, 0], 300, 0, puG);
    round("power.lever.shaft", lv, frame([xo - 190, 60, 1375], NX, Z), 0, 120, 9, { material: "chrome" });
    round("power.lever.knob", lv, frame([xo - 190, 60, 1375], NX, Z), 120, 165, [18, 14], { material: "rubber" });
    const jb = box("power.junction", puG, [xo - 105 - 40, xo - 105 + 40], [85, 150], [1520, 1620], { material: "gunmetal", r: 8 });
    face(jb, "front", [xo - 105, 150.05, 1570], text(0, 12, "400V", 34, { family: MONO, weight: 600, tone: "hi" }));
    for (const [i, xx] of [xo - 150, xo - 60].entries()) {
      round(`power.fitting.${i}`, puG, frame([xx, 100, 1375], Y, Z), 0, 26, 18, { material: "brass", details: { seams: [12] } });
      round(`power.hose.${i}`, puG, frame([xx, 100, 1375], Y, Z), 26, 60, 13, { material: "rubber" });
    }
    anchors.motor = [xo - 105, 0, 1500];
    anchors.power = [xo - 120, 0, 1350];
    void motor;
  }
  // Control box on the left post front.
  const ctlG = assembly("control", Y, 620, 0.02);
  {
    const x0 = -(PX + H) + 20;
    const cb = box("control.box", ctlG, [x0, x0 + 230], [H, H + 70], [1300, 1620], { material: "porcelain", r: 12 });
    face(cb, "front", [x0 + 115, H + 70.05, 1460], `<rect x="-90" y="-140" width="180" height="70" rx="6" style="fill:#2b2b2b"/>` + text(0, -95, "DHC LIFT", 30, { style: "fill:#f2c230" }) + text(0, 105, "OMHOOG", 20, { family: MONO, weight: 600, tone: "mid" }) + line(rrect(-90, -150, 90, 150, 10), "mid"));
    const btnG = assembly("control.button", Y, 300, 0, ctlG);
    round("control.button", btnG, frame([x0 + 115, H + 70, 1450], Y, Z), 0, 28, 34, { material: "signal", details: { seams: [8] } });
    round("control.stop", btnG, frame([x0 + 115, H + 70, 1370], Y, Z), 0, 14, 18, { material: "rubber" });
    anchors.control = [x0 + 115, H + 98, 1440];
  }

  // ---------- The car ----------
  const { half: CW, len: CL, sill, belt, deck, wheelY, wheelR, track, tyreW } = CAR;
  const carUp = assembly("car", Z, 1100, 0, lift);
  const carG = assembly("car.out", Y, 3400, 0.3, carUp);
  const body = assembly("car.body", Z, 0, 0, carG);
  const sillP = box("car.sill", body, [-CW, CW], [-wheelY + wheelR + 50, wheelY - wheelR - 50], [sill, belt], { material: "dhc", r: 40 });
  for (const s of [-1, 1]) {
    let d = `M${-(wheelY - wheelR - 80)} -150H${wheelY - wheelR - 80}`;
    face(sillP, s > 0 ? "right" : "left", [s * (CW + 0.05), 0, (sill + belt) / 2], line(d, "mid") + line(`M${-(wheelY - wheelR - 80)} 150H${wheelY - wheelR - 80}`, "faint"), [0.04, 0.3]);
  }
  const front = side("car.bumper.f", body, [[1600, 250], [1980, 300], [2010, 560], [1990, belt], [1600, belt]], -CW + 20, CW - 20, { material: "dhc" });
  face(front, "front", [0, 2010.05, 470], `<rect x="-260" y="-60" width="520" height="110" rx="10" style="fill:#f6f2e8;stroke:#1a1a1a;stroke-width:4"/>` + text(0, 28, "DHC-1957", 84, { family: MONO, weight: 700, style: "fill:#1a1a1a;letter-spacing:.02em" }) + line(rrect(-700, 70, 700, 160, 30), "lo"));
  const rear = side("car.bumper.b", body, [[-1600, 250], [-1600, belt], [-1980, belt], [-2000, 560], [-1970, 300]], -CW + 20, CW - 20, { material: "dhc" });
  face(rear, "back", [0, -2000.05, 470], line(rrect(-700, 70, 700, 150, 30), "lo"));
  const upper = side("car.upper", body, [[-1985, belt], [1995, belt], [1960, 880], [1300, deck], [-1900, deck], [-1985, 900]], -CW, CW, { material: "dhc", bevel: 14 });
  {
    // Headlights and grille on the nose; doors on the flanks.
    const nose = `<path d="M-760 -60h300l-40 110h-260z" style="fill:#f6f2e8;stroke:#1a1a1a;stroke-width:4"/><path d="M760 -60h-300l40 110h260z" style="fill:#f6f2e8;stroke:#1a1a1a;stroke-width:4"/>` + `<rect x="-360" y="-30" width="720" height="70" rx="20" style="fill:#2b2b2b"/>` + line("M-330 -5H330M-330 15H330", "mid");
    plane(upper, [0, 1978, 765], [-1, 0, 0], unit([0, 35, -230]), nose, unit([0, 1, 0.15]));
    const tail = `<rect x="-820" y="-90" width="230" height="110" rx="14" style="fill:#c8312b"/><rect x="590" y="-90" width="230" height="110" rx="14" style="fill:#c8312b"/>` + line("M-560 -70H560", "faint");
    face(upper, "back", [0, -1985.05, 790], tail);
    for (const s of [-1, 1]) {
      const doors = line(`M-500 -${(deck - belt) / 2 - 10}V${(deck - belt) / 2 - 10}M600 -${(deck - belt) / 2 - 10}V${(deck - belt) / 2 - 10}M-1400 -${(deck - belt) / 2 - 10}V0`, "mid") + `<rect x="-380" y="-110" width="120" height="26" rx="12" style="fill:#2b2b2b"/><rect x="420" y="-110" width="120" height="26" rx="12" style="fill:#2b2b2b"/>` + line("M-1900 60H1900", "faint");
      plane(upper, [s * (CW + 0.05), 0, (belt + deck) / 2], s > 0 ? [0, -1, 0] : Y, NZ, doors, [s, 0, 0]);
    }
  }
  const cabG = assembly("car.cabin", Z, 800, 0.55, carG);
  const cab = side("car.cabin", cabG, [[-1760, deck], [760, deck], [60, 1440], [-1600, 1450]], -CW + 90, CW - 90, { material: "dhc", bevel: 18 });
  {
    const glass = "fill:#33404a";
    for (const s of [-1, 1]) {
      // Side windows, drawn in (y, z) seen from outside.
      const w = (yy, zz) => `${(s > 0 ? -1 : 1) * yy} ${-(zz - 1220)}`;
      const svg = `<path d="M${w(640, 1030)}L${w(80, 1400)}L${w(-560, 1405)}L${w(-560, 1030)}Z" style="${glass}"/><path d="M${w(-640, 1030)}L${w(-640, 1405)}L${w(-1500, 1410)}L${w(-1660, 1030)}Z" style="${glass}"/>`;
      plane(cab, [s * (CW - 90 + 0.05), 0, 1220], s > 0 ? [0, -1, 0] : Y, NZ, svg, [s, 0, 0]);
    }
    const wsDir = unit([0, 60 - 760, 1440 - deck]);
    const wsN = unit([0, 1440 - deck, 760 - 60]);
    const mid = [0, (760 + 60) / 2, (deck + 1440) / 2];
    const lenWS = Math.hypot(700, 440);
    plane(cab, add(mid, mul(wsN, 0.05)), [-1, 0, 0], mul(wsDir, -1), `<path d="M-660 ${-lenWS / 2 + 40}H660L720 ${lenWS / 2 - 30}H-720Z" style="${glass}"/>` + line(`M-200 ${lenWS / 2 - 60}L80 ${-lenWS / 2 + 120}`, "faint"), wsN);
    const rwDir = unit([0, -1600 + 1760, 1450 - deck]);
    const rwN = unit([0, -(1450 - deck), 160]);
    const rmid = [0, (-1760 - 1600) / 2, (deck + 1450) / 2];
    const lenRW = Math.hypot(160, 450);
    plane(cab, add(rmid, mul(rwN, 0.05)), X, mul(rwDir, -1), `<path d="M-620 ${-lenRW / 2 + 60}H620L660 ${lenRW / 2 - 50}H-660Z" style="${glass}"/>`, rwN);
    face(cab, "top", [0, -500, 1450.05], line("M-560 -900V700M560 -900V700", "mid"));
  }
  for (const s of [-1, 1]) {
    const g = assembly(`car.mirror.${s > 0 ? "R" : "L"}`, [s, 0.3, 0.4], 500, 0, cabG);
    box(`car.mirror.${s > 0 ? "R" : "L"}`, g, s > 0 ? [CW - 90, CW + 60] : [-CW - 60, -CW + 90], [560, 660], [deck + 40, deck + 140], { material: "dhc", r: 20 });
  }
  anchors.car = [0, 0, 900];
  anchors.nose = [0, 2000, 650];
  anchors.cabin = [0, 0, 1250];
  for (const sx of [-1, 1])
    for (const sy of [-1, 1]) {
      const n = `wheel.${sx > 0 ? "R" : "L"}${sy > 0 ? "f" : "b"}`;
      const g = assembly(n, [sx, 0, -0.08], 700, 0.25, carG);
      const c = [0, sy * wheelY, wheelR];
      const F = frame(c, X, Z);
      const a = sx * track;
      const b = sx * (track + tyreW);
      const tyre = round(`${n}.tyre`, g, F, Math.min(a, b), Math.max(a, b), wheelR, { material: "rubber", details: { ribs: { s0: Math.min(a, b) + 20, s1: Math.max(a, b) - 20, count: 64, fade: [0.08, 0.5], tone: "lo" } } });
      const fx = sx * (track + tyreW + 0.05);
      let spokes = "";
      for (let k = 0; k < 5; k++) {
        const ang = (k / 5) * TAU;
        spokes += `M${(60 * Math.cos(ang)).toFixed(1)} ${(60 * Math.sin(ang)).toFixed(1)}L${(185 * Math.cos(ang)).toFixed(1)} ${(185 * Math.sin(ang)).toFixed(1)}`;
      }
      plane(tyre, [fx, sy * wheelY, wheelR], sx > 0 ? [0, -1, 0] : Y, NZ, `<circle r="215" style="fill:#d9d6cf"/><circle r="195" style="fill:#5a5852"/><path d="${spokes}" style="fill:none;stroke:#d9d6cf;stroke-width:22;stroke-linecap:round"/>` + line(ring(215, 80), "mid") + line(ring(250, 80), "faint"), [sx, 0, 0], [0.04, 0.3]);
      const capS = sx * (track + tyreW);
      round(`${n}.cap`, g, F, Math.min(capS, capS + sx * 18), Math.max(capS, capS + sx * 18), 62, { material: "chrome", details: { bolts: [{ s: capS + sx * 18, r: 42, count: 5, size: 1.2, tone: "lo" }] } });
      anchors[n] = [sx * (track + tyreW), sy * wheelY, wheelR];
    }

  // ---------- Rolling oil drain beside the right post ----------
  {
    const dx = 2250;
    const dy = 700;
    const g = assembly("drain", [1, 0.3, 0.1], 900, 0.06);
    const F = up(dx, dy);
    round("drain.base", g, F, 90, 130, 230, { material: "gunmetal" });
    for (let k = 0; k < 3; k++) {
      const a = (k / 3) * TAU + 0.5;
      const cx = dx + 190 * Math.cos(a);
      const cy = dy + 190 * Math.sin(a);
      round(`drain.fork.${k}`, g, up(cx, cy), 70, 90, 26, { material: "chrome" });
      round(`drain.wheel.${k}`, g, frame([cx, cy, 36], [Math.cos(a + Math.PI / 2), Math.sin(a + Math.PI / 2), 0], Z), -14, 14, 34, { material: "rubber" });
    }
    const tank = round("drain.tank", g, F, 130, 560, [170, 180], { material: "signal", details: { seams: [180, 520] } });
    void tank;
    round("drain.mast", g, F, 560, 1020, 30, { material: "chrome" });
    const fun = round("drain.funnel", g, F, 1020, 1120, [60, 300], { material: "dhc", details: { seams: [1040] } });
    plane(fun, [dx, dy, 1120.05], [-1, 0, 0], Y, `<circle r="290" style="fill:#2a2a2a"/>` + line(ring(240, 64), "lo") + line(`M-200 0H200M0 -200V200`, "mid"), Z);
    anchors.drain = [dx, dy, 900];
  }

  anchors.body = [0, 0, 1400];
  anchors.lift = [0, 0, 700];
  anchors.beam = [0, 70, TOP + 90];
  anchors.plate = [PX, H, 1700];
  anchors.post = [-PX, H, 1300];
  for (let i = 0; i <= 8; i++) features.push({ lift: (travel * i) / 8 });
  return { parts, groups, explode, root, anchors, features, counts: { posts: 2, arms: 4 } };
}
export function explodeValues(explode, apart, { stretch = 0.55 } = {}) {
  const out = {};
  for (const { name, travel, delay } of explode) {
    const t = Math.max(0, Math.min(1, (apart - delay * stretch) / (1 - stretch)));
    out[name] = travel * t * t * (3 - 2 * t);
  }
  return out;
}
