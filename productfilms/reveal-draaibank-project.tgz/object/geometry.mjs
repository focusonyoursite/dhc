import * as G from "../kit/lathe.mjs";
const TAU = Math.PI * 2;
const unit = G.unit3;
const add = G.add3;
const mul = G.mul3;
const sub = G.sub3;
const dot = G.dot3;
const cross = G.cross3;
export const frame = (o, a, u) => {
  const A = unit(a);
  const U = unit(sub(u, mul(A, dot(u, A))));
  return { o, a: A, u: U, v: cross(A, U) };
};
const X = [1, 0, 0];
const Y = [0, 1, 0];
const Z = [0, 0, 1];
const NX = [-1, 0, 0];
const NY = [0, -1, 0];
const NZ = [0, 0, -1];

// Bench metal lathe on a cabinet stand: 1000 mm between centres, 125 mm centre height. Millimetres.
export const LATHE = { bed: 1000, axis: 1125, ways: 1018 };
const FONT = "'Big Shoulders Display','Arial Narrow',Arial,sans-serif";
const MONO = "'IBM Plex Mono',Menlo,monospace";

const ring = (r, steps = 72, cx = 0, cy = 0) =>
  Array.from({ length: steps }, (_, j) => {
    const a = (TAU * j) / steps;
    return `${j ? "L" : "M"}${(cx + r * Math.cos(a)).toFixed(2)} ${(cy + r * Math.sin(a)).toFixed(2)}`;
  }).join("") + "Z";
const rrect = (x0, y0, x1, y1, r) =>
  `M${x0 + r} ${y0}H${x1 - r}A${r} ${r} 0 0 1 ${x1} ${y0 + r}V${y1 - r}A${r} ${r} 0 0 1 ${x1 - r} ${y1}H${x0 + r}A${r} ${r} 0 0 1 ${x0} ${y1 - r}V${y0 + r}A${r} ${r} 0 0 1 ${x0 + r} ${y0}Z`;
const text = (x, y, s, size, { tone = "hi", anchor = "middle", weight = 700, family = FONT, style = "" } = {}) =>
  `<text class="iso-face-text" data-tone="${tone}" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}" style="font-family:${family};letter-spacing:.06em;${style}" transform="translate(${x.toFixed(2)} ${y.toFixed(2)})">${s}</text>`;
const line = (d, tone = "lo") => `<path class="iso-line" data-tone="${tone}" d="${d}"/>`;
function roundedRect(u0, v0, u1, v1, r, steps = 6) {
  const out = [];
  const corner = (cu, cv, a0) => {
    for (let j = 0; j <= steps; j++) {
      const a = a0 + (j / steps) * (Math.PI / 2);
      out.push([cu + r * Math.cos(a), cv + r * Math.sin(a)]);
    }
  };
  corner(u0 + r, v0 + r, Math.PI);
  corner(u1 - r, v0 + r, 1.5 * Math.PI);
  corner(u1 - r, v1 - r, 0);
  corner(u0 + r, v1 - r, 0.5 * Math.PI);
  return out;
}

export function buildObject(T, { layer }) {
  const parts = {};
  const groups = {};
  const explode = [];
  const anchors = {};
  const features = [];
  const L = layer;
  const root = T.group("root", { free: { origin: [0, 0, 900] } });
  groups.root = root;
  const assembly = (name, dir, travel, delay = 0, parent = root) => {
    const g = T.group(name, { parent, slide: { direction: unit(dir), travel } });
    groups[name] = g;
    explode.push({ name, travel, delay });
    return g;
  };
  const part = (p) => (parts[p.name] = p);
  const prism = (name, group, F, poly, s0, s1, o = {}) =>
    part(T.prism({ name, group, layer: L, F, polygon: poly, s0, s1, steps: 5, tone: o.tone ?? "hi", crease: o.crease ?? "lo", bevel: o.bevel ?? 0, material: o.material, lit: o.lit, details: o.details }));
  const round = (name, group, F, s0, s1, r, o = {}) =>
    part(T.round({ name, group, layer: L, F, s0, s1, r, ends: o.ends, tone: o.tone ?? "hi", crease: o.crease ?? "lo", material: o.material, lit: o.lit, details: o.details }));
  const plane = (p, o, u, v, svg, normal, fade = [0.04, 0.3]) => T.plane({ part: p, o, u, v, svg, normal, fade });
  const FZ = frame([0, 0, 0], Z, X);
  const box = (name, group, [x0, x1], [y0, y1], [z0, z1], o = {}) =>
    prism(name, group, FZ, o.r ? roundedRect(x0, y0, x1, y1, o.r) : [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], z0, z1, o);
  const FX = frame([0, 0, 0], X, Y);
  const side = (name, group, poly, x0, x1, o = {}) => prism(name, group, FX, poly, x0, x1, o);
  const up = (x, y) => frame([x, y, 0], Z, X);
  const FACE = {
    front: { u: [-1, 0, 0], v: NZ, n: Y },
    back: { u: X, v: NZ, n: NY },
    right: { u: Y, v: NZ, n: X },
    left: { u: NY, v: NZ, n: NX },
    top: { u: [-1, 0, 0], v: Y, n: Z },
  };
  const face = (p, f, o, svg, fade) => plane(p, o, FACE[f].u, FACE[f].v, svg, FACE[f].n, fade);
  const AXZ = LATHE.axis;
  const WAY = LATHE.ways;
  const BED = LATHE.bed;
  const AXF = frame([0, 0, AXZ], X, Z); // the spindle axis, s along +x
  const knurl = (s0, s1, count = 60) => ({ ribs: { s0, s1, count, fade: [0.08, 0.55], seams: true, tone: "lo" } });

  // ---------- Stand ----------
  const tray = box("stand.tray", root, [-680, 680], [-390, 290], [820, 850], { material: "gunmetal", r: 16 });
  {
    let d = "";
    for (let x = -600; x <= 600; x += 60) d += `M${x} -240L${x + 30} 240`;
    face(tray, "top", [0, -50, 850.05], line(d, "faint"), [0.1, 0.6]);
  }
  for (const [n, x0, x1, dir] of [["L", 260, 660, X], ["R", -660, -300, NX]]) {
    const g = assembly(`cabinet.${n}`, dir, 420, 0.42);
    const cab = box(`cabinet.${n}`, g, [x0, x1], [-240, 230], [70, 820], { material: "porcelain", crease: "faint" });
    box(`cabinet.${n}.plinth`, g, [x0 + 20, x1 - 20], [-220, 210], [0, 70], { material: "gunmetal" });
    face(cab, n === "L" ? "right" : "left", [n === "L" ? x1 + 0.05 : x0 - 0.05, 0, 445], line("M-180 -340H180M-180 340H180", "faint"));
    const dg = assembly(`door.${n}`, Y, 300, 0.3, g);
    const door = box(`door.${n}`, dg, [x0 + 15, x1 - 15], [230, 246], [95, 800], { material: "porcelain", r: 6 });
    const w = (x1 - x0) / 2 - 30;
    let svg = line(rrect(-w + 20, -330, w - 20, -150, 8), "faint");
    if (n === "L") svg += line(`M${-w + 20} -10H${w - 20}M${-w + 20} 160H${w - 20}`, "mid") + `<rect x="-50" y="-95" width="100" height="16" rx="8" style="fill:#3a3a3c"/><rect x="-50" y="75" width="100" height="16" rx="8" style="fill:#3a3a3c"/><rect x="-50" y="245" width="100" height="16" rx="8" style="fill:#3a3a3c"/>` + text(0, -245, "DHC", 70, { style: "fill:#2b2b2b" });
    else svg += `<rect x="${w - 70}" y="-40" width="18" height="140" rx="9" style="fill:#3a3a3c"/>` + text(0, -240, "GEREEDSCHAP", 30, { family: MONO, weight: 600, tone: "mid" });
    face(door, "front", [(x0 + x1) / 2, 246.05, 447], svg);
  }
  const splashG = assembly("splash", NY, 300, 0.2);
  const splash = box("splash", splashG, [-680, 680], [-390, -376], [850, 1330], { material: "steel", crease: "faint" });
  {
    let tools = "";
    for (let k = 0; k < 7; k++) tools += `<circle cx="${-480 + k * 60}" cy="-150" r="7" style="fill:#3a3a3c"/>` + line(`M${-480 + k * 60} -143V${-60 - (k % 3) * 25}`, "mid");
    face(splash, "front", [0, -375.95, 1090], line("M-640 -220H640M-640 200H640", "faint") + tools + text(330, -120, "DRACHTSTER HOBBY CLUB", 34, { tone: "mid", style: "letter-spacing:.3em" }) + text(330, -80, "SINDS 1957", 24, { family: MONO, weight: 600, tone: "lo" }));
  }

  // ---------- Bed, ways, lead screw ----------
  const bed = box("bed", root, [-640, 600], [-120, 120], [850, BED], { material: "gunmetal", crease: "lo", bevel: 4 });
  face(bed, "front", [-20, 120.05, 925], line("M-600 -50H600", "faint") + text(-480, 20, "D-250 × 1000", 26, { family: MONO, weight: 600, tone: "mid" }));
  for (const [n, y0, y1] of [["f", 78, 112], ["b", -112, -78]]) {
    const w = box(`way.${n}`, root, [-640, 600], [y0, y1], [BED, WAY], { material: "chrome", crease: "lo" });
    if (n === "f") face(w, "top", [-20, (y0 + y1) / 2, WAY + 0.05], line(`M-600 -6H600M-600 6H600`, "lo"));
  }
  const rack = box("bed.rack", root, [-640, 300], [120, 128], [960, 990], { material: "steel" });
  {
    let d = "";
    for (let x = -620; x <= 290; x += 8) d += `M${x} -12V12`;
    face(rack, "front", [-170, 128.05, 975], line(d, "lo"), [0.06, 0.4]);
  }
  const screwG = assembly("leadscrew", Y, 260, 0.7);
  round("leadscrew", screwG, frame([0, 136, 905], X, Z), -600, 320, 11, { material: "chrome", details: { ribs: { s0: -590, s1: 310, count: 220, fade: [0.1, 0.6], tone: "lo" } } });
  round("feedrod", screwG, frame([0, 136, 870], X, Z), -600, 320, 9, { material: "chrome" });
  box("leadscrew.bracket", screwG, [-640, -600], [122, 165], [850, 930], { material: "gunmetal", r: 6 });

  // ---------- Headstock ----------
  const hsG = assembly("headstock", Z, 420, 0.32);
  const hs = box("headstock", hsG, [300, 640], [-160, 140], [WAY, 1260], { material: "porcelain", crease: "faint", r: 10 });
  {
    let svg = `<rect x="-150" y="-110" width="300" height="200" rx="10" style="fill:#e9e5dc;stroke:#8e8b85;stroke-width:2"/>`;
    svg += `<rect x="-135" y="-100" width="70" height="200" rx="8" style="fill:#d8d3c7"/>`;
    svg += text(10, -62, "DHC", 46, { style: "fill:#f2b705;letter-spacing:.02em" }) + text(10, -32, "D-250 × 1000", 18, { family: MONO, weight: 600, tone: "mid" });
    for (let k = 0; k < 7; k++) {
      const a = -2.6 + k * 0.87;
      svg += line(`M${90 + 36 * Math.cos(a)} ${-20 + 36 * Math.sin(a)}L${90 + 44 * Math.cos(a)} ${-20 + 44 * Math.sin(a)}`, "mid");
    }
    svg += text(90, 45, "70–2000 RPM", 16, { family: MONO, weight: 600, tone: "mid" }) + text(-100, -20, "NOOD", 13, { family: MONO, weight: 600, tone: "mid" }) + text(-100, 105, "AAN", 13, { family: MONO, weight: 600, tone: "mid" });
    face(hs, "front", [470, 140.05, 1135], svg);
  }
  const lidG = assembly("headstock.lid", Z, 380, 0.04, hsG);
  const lid = box("headstock.lid", lidG, [310, 630], [-150, 130], [1260, 1276], { material: "porcelain", r: 10 });
  {
    let t = "";
    const sp = [70, 130, 230, 410, 720, 1250, 1450, 2000];
    for (let i = 0; i < 8; i++) t += text(-120 + (i % 4) * 80, -40 + Math.floor(i / 4) * 50, String(sp[i]), 20, { family: MONO, weight: 600, tone: "mid" });
    face(lid, "top", [470, -10, 1276.05], `<rect x="-150" y="-90" width="300" height="140" rx="8" style="fill:#d8d3c7"/>` + t + line("M-150 -15H150", "faint"));
  }
  // Control buttons on the headstock front.
  const ctlG = assembly("controls", Y, 300, 0.02, hsG);
  round("estop", ctlG, frame([570, 140, 1200], Y, Z), 0, 26, 30, { material: "signal", details: { seams: [10] } });
  round("estop.collar", ctlG, frame([570, 140, 1120], Y, Z), 0, 12, 22, { material: "dhc" });
  round("switch.on", ctlG, frame([570, 140, 1060], Y, Z), 0, 14, 16, { material: "rubber" });
  round("speed.knob", ctlG, frame([380, 140, 1155], Y, Z), 0, 30, 26, { material: "rubber", details: knurl(4, 28, 40) });
  anchors.controls = [570, 160, 1160];
  // Spindle, chuck and work piece turn together.
  const spin = T.group("spindle", { parent: hsG, hinge: { point: [0, 0, AXZ], axis: X, range: [-7200, 7200] } });
  groups.spindle = spin;
  const chuckG = assembly("chuck", Z, 420, 0.16, spin);
  round("spindle.nose", chuckG, AXF, 270, 300, 52, { material: "steel", details: { seams: [285] } });
  round("chuck.back", chuckG, AXF, 245, 270, 66, { material: "gunmetal" });
  const chuck = round("chuck.body", chuckG, AXF, 190, 245, 80, { material: "chrome", details: { seams: [205, 232], bolts: [{ s: 190, r: 70, count: 3, size: 2.4, tone: "lo" }] } });
  void chuck;
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * TAU + Math.PI / 2;
    const dir = [0, Math.cos(a), Math.sin(a)];
    const jg = assembly(`jaw.${k}`, dir, 160, 0.1, chuckG);
    const JF = frame([0, 0, AXZ], dir, X);
    // polygon in (u = x, v = dir × x), extruded radially from r 19 to r 66
    prism(`jaw.${k}`, jg, JF, [[160, -11], [190, -11], [190, 11], [160, 11]], 19, 66, { material: "steel", bevel: 1 });
  }
  const workG = assembly("work", Z, 520, 0.08, spin);
  round("work.stock", workG, AXF, -40, 158, 18, { material: "steel", details: { seams: [120] } });
  round("work.turned", workG, AXF, -268, -40, 13, { material: "chrome", details: { ribs: { s0: -260, s1: -48, count: 30, tone: "faint" } } });
  anchors.chuck = [190, 0, AXZ];
  anchors.work = [-60, 0, AXZ];
  const guardG = assembly("chuck.guard", Z, 560, 0.03, hsG);
  const cg = side("chuck.guard", guardG, [[-100, 1212], [100, 1212], [80, 1240], [-80, 1240]], 176, 298, { material: "dhc", bevel: 2 });
  face(cg, "top", [237, 0, 1240.05], line("M-50 -60V60M50 -60V60", "faint"));
  // Motor and belt cover at the back.
  const motorG = assembly("motor", X, 520, 0.26);
  round("motor", motorG, frame([0, -240, 1110], X, Z), 380, 600, 78, { material: "gunmetal", details: knurl(400, 560, 48) });
  round("motor.fan", motorG, frame([0, -240, 1110], X, Z), 600, 630, [78, 62], { material: "gunmetal" });
  box("motor.box", motorG, [440, 540], [-250, -230], [1188, 1250], { material: "gunmetal", r: 6 });
  // Gearbox under the headstock.
  const gbG = assembly("gearbox", Y, 380, 0.22);
  const gb = box("gearbox", gbG, [320, 630], [120, 170], [870, 996], { material: "porcelain", r: 8 });
  {
    let svg = `<rect x="-140" y="-50" width="280" height="56" rx="6" style="fill:#d8d3c7"/>`;
    for (let i = 0; i < 6; i++) svg += text(-115 + i * 46, -16, ["0.5", "0.75", "1.0", "1.25", "1.5", "2.0"][i], 16, { family: MONO, weight: 600, tone: "mid" });
    face(gb, "front", [475, 170.05, 935], svg);
  }
  for (const [i, x] of [380, 470, 560].entries()) {
    const lg = assembly(`lever.${i}`, Y, 260, 0, gbG);
    round(`lever.${i}.shaft`, lg, frame([x, 170, 900], Y, Z), 0, 50, 7, { material: "chrome" });
    round(`lever.${i}.knob`, lg, frame([x, 170, 900], Y, Z), 50, 74, [13, 10], { material: "rubber" });
  }

  // ---------- Carriage ----------
  const feed = T.group("feed", { parent: root, slide: { direction: X, travel: 50 } });
  groups.feed = feed;
  const carG = assembly("carriage", Z, 440, 0.3, feed);
  const saddle = box("saddle", carG, [-130, 130], [-150, 150], [WAY, 1050], { material: "porcelain", r: 6 });
  void saddle;
  const apron = box("apron", carG, [-140, 140], [150, 190], [860, 1050], { material: "porcelain", r: 8 });
  face(apron, "front", [0, 190.05, 955], line(rrect(-120, -80, 120, 80, 8), "faint") + text(-70, 70, "DHC", 30, { style: "fill:#f2b705" }));
  const hwG = assembly("handwheel", Y, 300, 0.12, carG);
  const HWF = frame([50, 190, 950], Y, Z);
  round("handwheel.hub", hwG, HWF, 0, 20, 20, { material: "chrome" });
  const hw = round("handwheel.rim", hwG, HWF, 20, 34, 62, { material: "chrome", details: knurl(21, 33, 90) });
  plane(hw, [50, 224.05, 950], [-1, 0, 0], NZ, line(ring(48, 60), "mid") + line(ring(22, 40), "lo") + line("M0 -22V-48M19 11L42 24M-19 11L-42 24", "mid"), Y);
  round("handwheel.grip", hwG, frame([50 - 48, 224, 950], Y, Z), 0, 46, 9, { material: "rubber" });
  const hnG = assembly("halfnut", [0, 1, 0.3], 260, 0.1, carG);
  round("halfnut.shaft", hnG, frame([-80, 190, 900], Y, Z), 0, 36, 8, { material: "chrome" });
  round("halfnut.knob", hnG, frame([-80, 190, 900], Y, Z), 36, 56, [14, 11], { material: "signal" });
  anchors.handwheel = [50, 224, 950];
  const tdG = assembly("threaddial", Z, 300, 0.1, carG);
  round("threaddial.stem", tdG, up(-110, 172), 1050, 1066, 8, { material: "chrome" });
  const td = round("threaddial", tdG, up(-110, 172), 1066, 1084, 18, { material: "chrome" });
  {
    let d = "";
    for (let k = 0; k < 8; k++) d += `M${(10 * Math.cos((k * TAU) / 8)).toFixed(1)} ${(10 * Math.sin((k * TAU) / 8)).toFixed(1)}L${(15 * Math.cos((k * TAU) / 8)).toFixed(1)} ${(15 * Math.sin((k * TAU) / 8)).toFixed(1)}`;
    plane(td, [-110, 172, 1084.05], [-1, 0, 0], Y, `<circle r="16" style="fill:#f4f0e6"/>` + line(d, "hi") + line("M0 0L0 -12", "mid"), Z);
  }
  round("saddle.lock", carG, up(100, -125), 1050, 1068, 10, { material: "chrome" });
  for (const [i, yy] of [-125, 125].entries()) round(`saddle.oiler.${i}`, carG, up(-112, yy), 1050, 1060, 7, { material: "brass" });
  // Cross slide, compound, tool post, tool bit.
  const crossG = assembly("cross", Z, 300, 0.2, carG);
  box("cross.slide", crossG, [-80, 80], [-130, 140], [1050, 1074], { material: "porcelain", r: 5 });
  round("cross.screw", crossG, frame([0, 140, 1062], Y, Z), 0, 51, 9, { material: "chrome" });
  const collar = round("cross.collar", crossG, frame([0, 140, 1062], Y, Z), 51, 63, 22, { material: "chrome", details: { ribs: { s0: 52, s1: 62, count: 50, tone: "lo" } } });
  void collar;
  round("cross.wheel", crossG, frame([0, 140, 1062], Y, Z), 63, 77, 38, { material: "chrome", details: knurl(64, 76, 60) });
  const compG = assembly("compound", Z, 260, 0.12, crossG);
  box("compound", compG, [-55, 55], [30, 130], [1074, 1094], { material: "porcelain", r: 4 });
  const tpG = assembly("toolpost", Z, 300, 0.06, compG);
  const tp = box("toolpost", tpG, [-38, 38], [50, 120], [1094, 1162], { material: "gunmetal", r: 4 });
  face(tp, "front", [0, 120.05, 1128], line("M-30 -4H30M-30 6H30", "lo"));
  for (const [i, x] of [-18, 18].entries()) round(`toolpost.screw.${i}`, tpG, up(x, 85), 1162, 1176, 9, { material: "chrome" });
  round("toolpost.handle", tpG, up(0, 85), 1176, 1186, 22, { material: "chrome" });
  const bitG = assembly("toolbit", Z, 260, 0.02, tpG);
  const bit = prism("toolbit", bitG, frame([0, 0, 0], Y, Z), [[1117, -6], [1129, -6], [1129, 6], [1117, 6]], 21, 50, { material: "dhc" });
  void bit;
  anchors.tool = [0, 30, AXZ];

  // ---------- Tailstock ----------
  const tsG = assembly("tailstock", Z, 380, 0.24);
  box("tailstock.base", tsG, [-570, -400], [-115, 115], [WAY, 1050], { material: "porcelain", r: 6 });
  const tsb = box("tailstock.body", tsG, [-560, -420], [-70, 70], [1050, 1170], { material: "porcelain", r: 10 });
  face(tsb, "front", [-490, 70.05, 1110], line("M-50 -40H50", "faint") + text(0, 20, "MK2", 22, { family: MONO, weight: 600, tone: "mid" }));
  const quillG = assembly("quill", X, 100, 0.12, tsG);
  round("quill", quillG, AXF, -420, -340, 24, { material: "chrome", details: { seams: [-380] } });
  round("centre", quillG, AXF, -340, -273, [22, 4], { material: "steel" });
  const twG = assembly("tail.wheel", NX, 240, 0.06, tsG);
  round("tail.screw", twG, AXF, -590, -560, 10, { material: "chrome" });
  round("tail.wheel", twG, AXF, -612, -590, 52, { material: "chrome", details: knurl(-611, -591, 70) });
  const tlG = assembly("tail.clamp", Y, 220, 0.04, tsG);
  round("tail.clamp.shaft", tlG, frame([-485, 115, 1034], Y, Z), 0, 36, 7, { material: "chrome" });
  round("tail.clamp.knob", tlG, frame([-485, 115, 1034], Y, Z), 36, 54, [13, 10], { material: "rubber" });
  round("tail.lock", tsG, frame([-470, 0, 1170], Z, X), 0, 26, 12, { material: "signal" });
  anchors.tailstock = [-490, 0, AXZ];

  // ---------- Work lamp ----------
  const lampG = assembly("lamp", [-0.3, -0.3, 1], 700, 0.0);
  round("lamp.base", lampG, up(430, -110), 1276, 1290, 30, { material: "gunmetal" });
  round("lamp.post", lampG, up(430, -110), 1290, 1520, 10, { material: "chrome" });
  round("lamp.joint", lampG, up(430, -110), 1520, 1550, 16, { material: "gunmetal" });
  const armDir = unit([-1, 0.6, 0]);
  round("lamp.arm", lampG, frame([430, -110, 1560], armDir, Z), 0, 260, 9, { material: "chrome" });
  const hx = 430 + armDir[0] * 250;
  const hy = -110 + armDir[1] * 250;
  const head = round("lamp.head", lampG, up(hx, hy), 1440, 1550, [56, 26], { material: "dhc" });
  plane(head, [hx, hy, 1439.95], [-1, 0, 0], NY, `<circle r="50" style="fill:#fff6d6"/>` + line(ring(50, 48), "mid"), NZ);
  anchors.lamp = [hx, hy, 1500];

  anchors.body = [0, 0, 900];
  anchors.bed = [0, 120, 980];
  for (let i = 0; i <= 8; i++) features.push({ spindle: i * 45, feed: (50 * i) / 8 });
  return { parts, groups, explode, root, anchors, features, counts: {} };
}
export function explodeValues(explode, apart, { stretch = 0.55 } = {}) {
  const out = {};
  for (const { name, travel, delay } of explode) {
    const t = Math.max(0, Math.min(1, (apart - delay * stretch) / (1 - stretch)));
    out[name] = travel * t * t * (3 - 2 * t);
  }
  return out;
}
