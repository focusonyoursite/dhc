export const FILM = {
  fig: "DHC",
  title: "Draaibank",
  radius: 1180,
  label:
    "Een metaaldraaibank van de Drachtster Hobby Club op een onderkast: hij draait in beeld, zoomt in op de klauwplaat, de bedieningsknoppen en het handwiel van de slede, de klauwplaat draait terwijl de beitel langs het werkstuk loopt, en de bank valt uiteen in kast, bed, spindelkast, slede en losse kop en klikt weer in elkaar.",
  bounds: [
    [-680, 680],
    [-400, 300],
    [0, 1560],
  ],
};

export const FIGURE = {
  title: "Draaibank · anatomie",
  start: { yaw: -24, pitch: 18 },
  label:
    "Een metaaldraaibank met 1000 mm tussen de centers, opgebouwd uit {parts} losse onderdelen: een onderkast met deuren en spaanbak, het bed met geleidingen, heugel, leidspindel en trekstang, de spindelkast met klauwplaat, drie klauwen, motor en tandwielkast, de slede met handwiel, dwarsslede, bovenslede, beitelhouder en beitel, de losse kop met pinole en center, en een werklamp. Uit elkaar zijn het {assemblies} delen.",
  keys: [
    { mark: "raised", label: "Onderkast, bed en geleidingen" },
    { mark: "lit", label: "Spindelkast, klauwplaat en werkstuk: draaien rond" },
    { mark: "edge", label: "Slede, beitelhouder en losse kop: bewegen langs het bed" },
  ],
  caption:
    "{parts} bolle onderdelen, elk frame opnieuw geprojecteerd en gearceerd. Eerst gaan de lamp, het werkstuk en de beitel eraf, dan de klauwen en de klauwplaat, de dwarsslede en de losse kop; daarna komen de spindelkast, de slede en de leidspindel los en schuiven de kasten opzij.",
};

export const FEATURE_DEFAULTS = { spin: 0, feed: 0 };

export const FEATURE_KEYS = [
  { key: "s", channel: "spin", name: "toeren", unit: "°", step: 360, ease: 0.2, verb: "laat de klauwplaat draaien" },
  { key: "f", channel: "feed", name: "voeding", unit: "", values: [0, 1], ease: 0.25, verb: "laat de slede langs het werkstuk lopen" },
];

const clamp01 = (x) => Math.max(0, Math.min(1, x));

export function featureValues(s, values) {
  return { ...values, spindle: s.spin, feed: 50 * clamp01(s.feed) };
}

export function featureTravel(a, b) {
  return Math.max((Math.abs(b.spin - a.spin) * Math.PI * 80) / 180, Math.abs(b.feed - a.feed) * 50);
}
